from .PyVectors import *
import pygame, time
import math as Math

# --- classes ---


class mesh3D:  # work on this
    def __init__(self, triangles):
        self.tris = triangle
        self.progected = []
    def progectPoint(self, point, camPos):
        return Vec2(point.x / (point.z - camPos.z), point.y / (point.z - camPos.z))
    def project(self, camPos):
        self.progected = []
        for tri in self.tris:
            self.progected.append(Vec2(triangle(Vec2(self.progectPoint(tri.pos1)), Vec2(self.progectPoint(tri.pos2)), Vec2(self.progectPoint(tri.pos3)), tri.color), tri))  # test this projection method (triProgected = tri.xy / (tr.z - camPos.z))
    def render(self):
        pass  # render self.progected


class triangle:
    def __init__(self, pos1, pos2, pos3, color):  # add sprite rendering
            self.pos1 = pos1
            self.pos2 = pos2
            self.pos3 = pos3
            self.color = color


class collideBox:
    def __init__(self, image):
        self.size = Vec2(image.size[0], image.size[1])
        self.image = image
        self.pos = Vec2(image.pos[0], image.pos[1])
    def collidePoint(self, point):
        return point.x in range(self.pos.x, self.pos.x + self.size.x) and point.y in range(self.pos.y, self.pos.y + self.size.y)
    def collideWith(self, otherCollider):
        return (other.Collider.pos.x in range(self.pos.x, self.pos.x + self.size.x) or other.Collider.pos.x + other.size.x in range(self.pos.x, self.pos.x + self.size.x)) and (other.Collider.pos.y in range(self.pos.y, self.pos.y + self.size.y) or other.Collider.pos.y + other.size.y in range(self.pos.y, self.pos.y + self.size.y))


class collider:
    def __init__(self, colliderImage):
        self.image = colliderImage
        self.collideList = []  # make this a 2d list of the red spaces in the image
    def checkColldide(self, pos):
        return self.collideList[pos.x][pos.y]


class camera:  # test this object
    def __init__(self, parent, scale = 1, smoothness = 5):
        self.pos = parent.pos
        self.smoothness = smoothness
        self.parent = parent
        self.scale = scale
    def move(self):
        self.pos = (self.parent.pos - (self.pos + res / vec2(2))) / vec2(self.smoothness)


class particle:
    def __init__(self, pos, decay, particleImage, aiParent):
        self.ai = aiParent
        self.image = particleImage
        self.pos = pos
        self.aliveFor = decay
        self.data = {}
        self.size = Vec2(self.image.get_width(), self.image.get_height())
    def render(self):
        draw.blit(self.image, self.pos - (self.pos // self.size))
    def move(self):
        self.aliveFor -= 1 * events.deltaTime
        data = self.ai.move(self)
        self.pos = data[0]
        self.data = data[1]


class enimy:
    def __init__(self, sprite, pos, speed, aiChild, health = 25):
        self.sprite = sprite
        self.pos = pos
        self.speed = speed
        self.ai = aiChild
        self.data = {}
        self.health = health
        self.size = Vec2(self.sprite.get_width(), self.sprite.get_height())
    def render(self):
        draw.blit(self.sprite, self.pos - (self.size // Vec2(2, 2)))
    def move(self):
        data = self.ai.move(self)
        self.pos = data[0]
        self.data = data[1]


class player:
    def __init__(self, sprite, pos, speed, health = 25):
        self.pos = pos
        self.speed = speed
        self.health = health
        self.sprite = sprite  # add an animation class and attach it
        self.size = Vec2(self.sprite.get_width(), self.sprite.get_height())
    def render(self):
        draw.blit(self.sprite, self.pos - (self.size // Vec2(2, 2)))
    def move(self, moved):
        self.pos += moved * vec2(self.speed)


class tileMap:  # test this object
    def __init__(self, palet, fileName):  # make it so the player can go behind objects
        self.name = fileName
        self.map = {}
        self.palet = palet
    def addTile(self, pos, tile):
        map[str(pos)] = tile
    def saveMap(self):
        saveList = []
        for key in map:
            saveList.append([key + ',' + str(map[key]), '|'])
        saveString = ''
        for l in range(len(saveList) - 1):
            saveString += saveList[l][0] + saveList[l][1]
        saveString += saveList[len(saveList) - 1][0]
        return saveString
    def render(self, cam):
        for x in range(Math.ceil(res.x / self.palet.scale.x * cam.scale)):
            for y in range(Math.ceil(res.y / self.palet.scale.y * cam.scale)):
                try:
                    draw.blit(self.palet.images[map[str(Vec2(x, y))]], round(Vec2(x, y) * self.palet.scale))
                except KeyError:
                    pass


class tilePalet:  # test this object (add more to it)
    def __init__(self, tiles):
        self.tiles = tiles


class eventManager:
    def __init__(self):
        self.held = {}
        self.down = {}
        self.up = {}
        self.keyCodes = []
        self.keyNames = []

        self.mousePos = vec2(0)

        self.keysPressed = {'down': [], 'up': []}

        self.FrameLockedFor = 0
        self.deltaTime = 0

        self.alphabet = 'a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,1,2,3,4,5,6,7,8,9,0, ,.,/,;,\',[,],\\,=,-,`'.split(',').append(',')
        self.ShiftAlphabet = 'A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,!,@,#,$,%,^,&,*,(,), ,>,?,:,\",{,},|,+,_,~'.split(',').append('<')

        self.keys = 'a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,1,2,3,4,5,6,7,8,9,0, ,.,/,;,\',[,],\\,=,-,`'.split(',')  # add more to this list    
        self.pygameCodes = [pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN, pygame.K_LSHIFT, pygame.K_RSHIFT, pygame.K_BACKSPACE, pygame.K_TAB, pygame.K_RCTRL, pygame.K_LCTRL, pygame.K_ESCAPE]  # add all the pygame keycodes to here that arnt in the ord function
        self.pygameNames = ['left', 'right', 'up', 'down', 'Lshift', 'Rshift', 'backSpace', 'tab', 'Rctrl', 'Lctrl', 'esc']
        
        for t in self.keys:
            self.held[t] = False
            self.down[t] = False
            self.up[t] = False
            self.keyCodes.append(ord(t))
            self.keyNames.append(t)
        for t in self.pygameCodes:
            name = self.pygameNames[self.pygameCodes.index(t)]
            self.held[name] = False
            self.down[name] = False
            self.up[name] = False
            self.keyCodes.append(t)
            self.keyNames.append(name)
        self.down['mouse'] = False
        self.up['mouse'] = False
        self.held['mouse'] = False
    def reset(self):
        self.keysPressed = {'down': [], 'up': []}

        for t in self.keys:
            self.down[t] = False 
            self.up[t] = False
        for t in self.pygameCodes:
            name = self.pygameNames[self.pygameCodes.index(t)]
            self.down[name] = False
            self.up[name] = False
        self.down['mouse'] = False
        self.up['mouse'] = False


class image:
    def load(image):
        return pygame.image.load(image)
    def createImage(list, name):
        png.fromArray(list, name + '.png')
    def getPixels(image):
        png.getArray(image + '.png')


class draw:
    def fill(color):
        screen.fill(color)
    def rect(color, pos, size, center = False):
        if center:
            pygame.draw.rect(screen, color, [pos.x - (size.x // 2), pos.y - (size.y // 2), size.x, size.y])
        else:
            pygame.draw.rect(screen, color, [pos.x, pos.y, size.x, size.y])
    def blit(image, pos, center = False):
        if center:
            screen.blit(image, pos - Vec2(image.get_width() // 2, image.get_height() // 2))
        else:
            screen.blit(image, pos)
    def circle(color, pos, r, center = False):
        if center:
            pygame.draw.circle(screen, color, pos - vec2(r // 2), r)
        else:
            pygame.draw.circle(screen, color, pos, r)
    def polygon(color, poses):
        pygame.draw.polygon(screen, color, poses)
    def line(color, pos1, pos2, thickness = 1):
        pygame.draw.line(screen, color, pos1, pos2, thickness)
    def text(text, color, pos, size, center = False, font = 'pixel.ttf'):
        largeText = pygame.font.Font(font, size)
        TextSurf, TextRect = text_objects(text, largeText, color)
        if center:
            TextRect.center = pos
            sprite = screen.blit(TextSurf, TextRect)
        else:
            sprite = screen.blit(TextSurf, pos)
        return sprite


#    def message_display(text, x, y, color, size, font = 'pixel.ttf', center = False):

# --- Functions ---


def lockFPS(fps):
    timePassed = events.deltaTime
    sleepAmount = (1 / fps) - ((timePassed / 20) - events.FrameLockedFor)
    time.sleep(max(sleepAmount, 0))
    events.FrameLockedFor = max(sleepAmount, 0)


def text_objects(text, font, color):
    textSurface = font.render(text, True, color)
    return textSurface, textSurface.get_rect()


# --- Inititializtion ---


def getEvents():
    global running
    events.reset()
    events.mousePos = pygame.mouse.get_pos()
    events.mousePos = vec2(events.mousePos[0], events.mousePos[1])
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            running = False
            break
        if event.type == pygame.KEYDOWN:
            if event.key in events.keyCodes:
                key = events.keyNames[events.keyCodes.index(event.key)]

                events.keysPressed['down'].append(key)

                events.down[key] = True
                events.held[key] = True
        elif event.type == pygame.KEYUP:
            if event.key in events.keyCodes:
                key = events.keyNames[events.keyCodes.index(event.key)]

                events.keysPressed['up'].append(key)

                events.up[key] = True
                events.held[key] = False
            elif event.key == pygame.K_ESCAPE:
                pygame.quit()
                running = False
                break
        elif event.type == pygame.MOUSEBUTTONDOWN:
            events.down['mouse'] = True
            events.held['mouse'] = True
        elif event.type == pygame.MOUSEBUTTONUP:
            events.up['mouse'] = True
            events.held['mouse'] = False


def init(UpdateFunction, Res):
    global updateFunction, res, screen, events
    updateFunction = UpdateFunction
    res = Res
    screen = pygame.display.set_mode(res)


def run():
    # --- Main Loop ---
    while running:
        frameStart = time.time()
        
        getEvents()
        if not running:
            break
        
        updateFunction(events)

        pygame.display.update()
        
        events.deltaTime = (time.time() - frameStart) * 20


# --- Veriables ---

# --- Inititializtion ---

pygame.init()
events = eventManager()

res = None
updateFunction = None
screen = None
running = True

