from Packages.PyVectors import *
import pygame, time, random
import math as Math

PI2 = Math.pi / 2
PI22 = Math.pi * 2
PI3 = 3 * Math.pi / 2
MAPSIZE = 8 * 8  # not the true size but rather a good looking size for scaling of walls
TILESIZE = 64


def CellularAtomitu(size: vec2, itters: int, randomGenerator, cellularRule) -> list:
    randoms = []
    for x in range(size.x):
        layer = []
        for y in range(size.y):
            layer.append(randomGenerator(x, y))
        randoms.append(layer)
    for i in range(itters):
        final = []
        for x in range(size.x):
            layer = []
            for y in range(size.y):
                layer.append(cellularRule(randoms, x, y))
                randoms[x][y] = layer[y]
            final.append(layer)
    return final


def CaveRule(rands: list, x: int, y: int) -> int:
    lights = 0
    darks  = 0
    for X in range(-1, 2):
        for Y in range(-1, 2):
            pos = (x + X, y + Y)
            try:
                if rands[pos[0]][pos[1]] == 0:
                    darks += 1
                else:
                    lights += 1
            except IndexError:
                darks += 1
    if darks > 4:
        return 0
    else:
        return 1


def RandomGen(x: float, y: float) -> int:
    r = random.randint(0, 100)
    if r >= density:
        return 1
    else:
        return 0


density = 50
map = CellularAtomitu(Vec2(25, 25), 1, RandomGen, lambda rands, x, y: rands[x][y])

for x in range(25):
    for y in range(25):
        map[x][y] = 1 - map[x][y]

for x in range(25):
    map[x][0] = 1
    map[x][24] = 1
    map[0][x] = 1
    map[24][x] = 1

for x in range(25):
    line = ''
    for y in range(25):
        line += str(map[x][y])
    #txt.delete('ray_casting_map.map', x + 53)
    #txt.write('ray_casting_map.map', x + 53, line)


render_dist = 25

cos_table = {}
tan_table = {}
atan_table = {}
#sin_table = {}
total = round(PI22, 3) * 1000
for i in range(round(total) + 1):
    v = i / 1000
    cos_table[v] = math.cos(v)
    t = math.tan(v)
    tan_table[v] = t
    atan_table[v] = (-0.9999) / (t + 0.0001)
    #sin_table[v] = math.sin(v)
sqrt_table = {}
for i in range((32 * TILESIZE) ** 2):
    sqrt_table[i] = math.sqrt(i)


class UI:
    def text(text: str, color: Vec3, pos: Vec2, size: float, center: bool = False, font: str = 'pixel.ttf'):
        largeText = pygame.font.Font(font, size)
        textSurface = largeText.render(text, True, color)
        TextSurf, TextRect = textSurface, textSurface.get_rect()
        if center:
            TextRect.center = pos
            sprite = screen.blit(TextSurf, TextRect)
        else:
            sprite = screen.blit(TextSurf, pos)
        return sprite   


def CastRays() -> list:
    DR = math.floor(fov) * (Math.pi / 180) / (1200 / world_res)
    N_tile_size2 = n_tile_size2
    N_tile_size = n_tile_size
    Textures = textures
    TexturesD = texturesD
    TexturesD2 = texturesD2
    mob_map = mobs_map[level][:]
    Player_pos = player_pos
    Player_angle = player_angle
    World_floor_map = world_floor_map
    PI2 = Math.pi / 2
    PI22 = Math.pi * 2
    PI3 = 3 * Math.pi / 2
    h_player = player_pos / Vec2(2, 2)
    PI = Math.pi
    MAPSIZE = 11 * 11  # not the true size but rather a good looking size for scaling of walls
    TILESIZE = 64
    TILESIZE2 = TILESIZE - 1
    mss = MAPSIZE * 750
    mt = -TILESIZE
    x1 = ((Math.floor(Player_pos.x) >> 6) * TILESIZE) - 0.0001
    x2 = ((Math.floor(Player_pos.x) >> 6) * TILESIZE) + TILESIZE
    y1 = ((Math.floor(Player_pos.y) >> 6) * TILESIZE) - 0.0001
    y2 = ((Math.floor(Player_pos.y) >> 6) * TILESIZE) + TILESIZE
    rays = []
    depth_buffer = []
    scaler = (40 / TILESIZE)

    hit_mobH = False
    hit_mobV = False
    mobHP = (0, 0)
    mobVP = (0, 0)
    
    ray_angle = Player_angle - (math.floor(fov) * (Math.pi / 180) / 2)
    if ray_angle < 0:
        ray_angle += PI22
    elif ray_angle > PI22:
        ray_angle -= PI22
    for r in range(Math.ceil(1200 / world_res)):
        dof = 0
        distH = 1000000000000
        hx = Player_pos.x
        hy = Player_pos.y
        rra = round(ray_angle, 3)
        tan = tan_table[rra]
        aTan = atan_table[rra]
        if ray_angle > PI:
            ray_y = y1
            ray_x = (Player_pos.y - ray_y) * aTan + Player_pos.x
            y_offset = mt
            x_offset = -y_offset * aTan
        elif ray_angle < PI:
            ray_y = y2
            ray_x = (Player_pos.y - ray_y) * aTan + Player_pos.x
            y_offset = TILESIZE
            x_offset = -y_offset * aTan
        elif ray_angle in [0, PI]:
            ray_x = Player_pos.x
            ray_y = Player_pos.y
            dof = 100
        while dof < render_dist:
            mx = Math.floor(ray_x) >> 6
            my = Math.floor(ray_y) >> 6
            if mx > -1 and mx < 25 and my > -1 and my < 25:
                if world_map[mx][my] != 0:
                    hx = ray_x
                    hy = ray_y
                    distH = (Player_pos.x - ray_x) ** 2 + (Player_pos.y - ray_y) ** 2
                    dof = 100
                else:
                    if mob_map[mx][my]:  # check for mob
                        hit_mobH = True
                        mobHP = (ray_x, ray_y)
                    ray_x += x_offset
                    ray_y += y_offset
                    dof += 1
            else:
                dof = 100
        
        dof = 0
        distV = 1000000000000
        vx = Player_pos.x
        vy = Player_pos.y
        nTan = -tan
        if ray_angle > PI2 and ray_angle < PI3:
            ray_x = x1
            ray_y = (Player_pos.x - ray_x) * nTan + Player_pos.y
            x_offset = mt
            y_offset = -x_offset * nTan
        elif ray_angle < PI2 or ray_angle > PI3:
            ray_x = x2
            ray_y = (Player_pos.x - ray_x) * nTan + Player_pos.y
            x_offset = TILESIZE
            y_offset = -x_offset * nTan
        elif ray_angle in [0, PI]:
            ray_x = Player_pos.x
            ray_y = Player_pos.y
            dof = 100
        while dof < render_dist:
            mx = Math.floor(ray_x) >> 6
            my = Math.floor(ray_y) >> 6
            if mx > -1 and mx < 25 and my > -1 and my < 25:
                if world_map[mx][my] != 0:
                    vx = ray_x
                    vy = ray_y
                    distV = (Player_pos.x - ray_x) ** 2 + (Player_pos.y - ray_y) ** 2
                    dof = 100
                else:
                    if mob_map[mx][my]:  # check for mob
                        hit_mobV = True
                        mobVP = (ray_x, ray_y)
                    ray_x += x_offset
                    ray_y += y_offset
                    dof += 1
            else:
                dof = 100
        
        shade = 1
        if distV < distH:
            shade = 0.5
            ray_x = vx
            ray_y = vy
            distT = distV
            mob_p = mobVP
            hit_mob = hit_mobV
        else:
            ray_x = hx
            ray_y = hy
            distT = distH
            mob_p = mobHP
            hit_mob = hit_mobH
        
        hit_mob = False
        if hit_mobV and hit_mobH:
            #mob_p = (mobHP[0], mobVP[1])
            hit_mob = True

        tile = world_map[Math.floor(ray_x) >> 6][Math.floor(ray_y) >> 6]

        ca = Player_angle - ray_angle
        if ca < 0:
            ca += PI22
        elif ca > PI22:
            ca -= PI22
        ca = cos_table[round(ca, 3)]  #Math.cos(ca)
        distT = sqrt_table[math.floor(distT)]  #Math.sqrt(distT)
        distT *= ca
        depth = distT#math.clamp(distT / MAXDIST * 255, 0, 255)
        depth_buffer.append(depth)
        if tile != 0:
            try:
                line_height = math.floor(mss / distT)
                mrx = ray_x % TILESIZE
                mry = ray_y % TILESIZE
                #if line_height > 750:
                #    ty_offset = (line_height - 750) / 2
                #    line_height = 750
                line_o = 375 - (line_height >> 1)
                if shade == 1:
                    texture_x = math.floor(mrx * scaler)
                    if ray_angle > 180:
                        texture_x = 39 - texture_x
                else:
                    texture_x = math.floor(mry * scaler)
                    if ray_angle > 90 and ray_angle < 270:
                        texture_x = 39 - texture_x
                
                pixel_x = r * world_res
                if render_mode == 'textured':
                    if mrx == 0 and mry != 0:
                        render_collum(textsD[tile][texture_x], pixel_x, line_o, world_res, line_height)
                    elif mry == 0 and mrx != 0:
                        render_collum(textsD2[tile][texture_x], pixel_x, line_o, world_res, line_height)
                    elif (round(mrx - 0.497) == TILESIZE and math.floor(mry - 0.25) != TILESIZE):
                        render_collum(texts[tile][texture_x], pixel_x, line_o, world_res, line_height)
                    else:
                        render_collum(texts2[tile][texture_x], pixel_x, line_o, world_res, line_height)
                else:
                    if mry == 0 and mrx != 0:
                        pygame.draw.rect(screen, colorsD[tile], [pixel_x, line_o, world_res, line_height])
                    elif mrx == 0 and mry != 0:
                        pygame.draw.rect(screen, colorsD[tile], [pixel_x, line_o, world_res, line_height])
                    else:
                        pygame.draw.rect(screen, colors[tile], [pixel_x, line_o, world_res, line_height])
                
                if hit_mob:
                    pass
                    """
                    d = sqrt_table[math.floor((player_pos.x - mob_p[0]) ** 2 + (player_pos.y - mob_p[1]) ** 2)]
                    d *= ca
                    mob_height = math.floor(mss / d)
                    mob_o = 375 - (mob_height >> 1)
                    tx = math.floor(mob_p[0] % TILESIZE)
                    render_collum(mob_textures[0][tx], pixel_x, mob_o, world_res, mob_height)
                    #"""

                rays.append([ray_x / N_tile_size * N_tile_size2, ray_y / N_tile_size * N_tile_size2])
            except ZeroDivisionError:
                pass
        
        ray_angle += DR
        if ray_angle > PI22:
            ray_angle -= PI22
    return [rays, depth_buffer]


def render_collum(texture_row, x, y, scaleX, scaleY):
    screen.blit(pygame.transform.scale(texture_row, (math.floor(scaleX), math.floor(scaleY))), [x, y])


pygame.init()

res = Vec2(1600, 950)
screen = pygame.Surface(Vec2(1200, 750))
Rscreen = pygame.display.set_mode(res)

dt = 1
fov = 90
level = 0

held = {'w': False, 'a': False, 's': False, 'd': False, 'left': False, 'right': False, 'up': False, 'down': False, 'shift': False, 'e': False, ' ': False, 'g': False}
down = {'w': False, 'a': False, 's': False, 'd': False, 'left': False, 'right': False, 'up': False, 'down': False, 'shift': False, 'e': False, ' ': False, 'g': False}
up =   {'w': False, 'a': False, 's': False, 'd': False, 'left': False, 'right': False, 'up': False, 'down': False, 'shift': False, 'e': False, ' ': False, 'g': False}

render_mode = 'flat'
show_map = False

world_floor_map = txt.read('ray_casting_map_floors.map')
level_floor_maps = []
section = []
for x in range(len(world_floor_map)):
    if world_floor_map[x] not in ['LEVEL', 'END']:
        world_floor_map[x] = list(world_floor_map[x])
i = 0
for x in world_floor_map:
    if x in ['LEVEL', 'END']:
        if i != 0:
            level_floor_maps.append(section)
            section = []
    else:
        nl = []
        for y in range(len(x)):
            nl.append(int(x[y]))
        section.append(nl)
    i += 1

world_map = txt.read('ray_casting_map.map')
level_maps = []
section = []
for x in range(len(world_map)):
    if world_map[x] not in ['LEVEL', 'END']:
        world_map[x] = list(world_map[x])
i = 0
for x in world_map:
    if x in ['LEVEL', 'END']:
        if i != 0:
            level_maps.append(section)
            section = []
    else:
        nl = []
        for y in range(len(x)):
            nl.append(int(x[y]))
        section.append(nl)
    i += 1

colors = [vec3(0), vec3(255, 255, 255), vec3(0, 0, 255), vec3(255, 255, 0), vec3(139, 69, 19), vec3(160,82,45), vec3(139, 69, 19)]
colorsD = [vec3(0), vec3(255/1.75), vec3(0, 0, 255/1.75), vec3(255/1.75, 255/1.75, 0), vec3(139/1.75, 69/1.75, 19/1.75), vec3(160/1.75, 82/1.75, 45/1.75), vec3(139/1.75, 69/1.75, 19/1.75)]

cols = [None, png.getArray('ray_casting_textures/text1.png'), png.getArray('ray_casting_textures/text2.png'), png.getArray('ray_casting_textures/text3.png'), png.getArray('ray_casting_textures/text4.png'), png.getArray('ray_casting_textures/text5.png'), png.getArray('ray_casting_textures/text6.png')]
textures  = [None, png.getArray('ray_casting_textures/text1.png'), png.getArray('ray_casting_textures/text2.png'), png.getArray('ray_casting_textures/text3.png'), png.getArray('ray_casting_textures/text4.png'), png.getArray('ray_casting_textures/text5.png'), png.getArray('ray_casting_textures/text6.png')]
textures2 = [None, png.getArray('ray_casting_textures/text1.png'), png.getArray('ray_casting_textures/text2.png'), png.getArray('ray_casting_textures/text3.png'), png.getArray('ray_casting_textures/text4.png'), png.getArray('ray_casting_textures/text5.png'), png.getArray('ray_casting_textures/text6.png')]
texturesD = [None, png.getArray('ray_casting_textures/text1.png'), png.getArray('ray_casting_textures/text2.png'), png.getArray('ray_casting_textures/text3.png'), png.getArray('ray_casting_textures/text4.png'), png.getArray('ray_casting_textures/text5.png'), png.getArray('ray_casting_textures/text6.png')]
i = 0
for texture in textures2:
    if texture != None:
        for x in range(40):
            for y in range(40):
                textures2[i][x][y] = (textures2[i][x][y] / Vec4(1.15, 1.15, 1.15, 1.15)).rgb
    i += 1
i = 0
for texture in texturesD:
    if texture != None:
        for x in range(40):
            for y in range(40):
                texturesD[i][x][y] = (texturesD[i][x][y] / Vec4(1.75, 1.75, 1.75, 1.75)).rgb
    i += 1
texturesD2 = [None, png.getArray('ray_casting_textures/text1.png'), png.getArray('ray_casting_textures/text2.png'), png.getArray('ray_casting_textures/text3.png'), png.getArray('ray_casting_textures/text4.png'), png.getArray('ray_casting_textures/text5.png'), png.getArray('ray_casting_textures/text6.png')]
i = 0
for texture in texturesD:
    if texture != None:
        for x in range(40):
            for y in range(40):
                texturesD2[i][x][y] = (texturesD2[i][x][y] / Vec4(1.4, 1.4, 1.4, 1.4)).rgb
    i += 1


def collum(colors):
    surf = pygame.Surface((1, 40))
    i = 0
    for col in colors:
        pygame.draw.rect(surf, col, [0, i, 1, 1])
        i += 1
    surf.convert()
    surf.set_colorkey((0, 0, 0))
    return surf

texts   = [None]
texts2  = [None]
textsD  = [None]
textsD2 = [None]
for text_ in textures:
    row = []
    if text_ != None:
        for text in text_:
            row.append(collum(text))
        texts.append(row)
for text_ in textures2:
    row = []
    if text_ != None:
        for text in text_:
            row.append(collum(text))
        texts2.append(row)
for text_ in texturesD:
    row = []
    if text_ != None:
        for text in text_:
            row.append(collum(text))
        textsD.append(row)
for text_ in texturesD2:
    row = []
    if text_ != None:
        for text in text_:
            row.append(collum(text))
        textsD2.append(row)


def get_array_from_surf(image):
    im = pygame.transform.scale(pygame.image.load(image), (40, 40))
    surf = pygame.Surface((40, 40))
    surf.blit(im, [0, 0])
    #surf.convert()
    #surf.set_colorkey((0, 0, 0))
    return surf


def collum2(surf, p):
    surf_ = pygame.Surface((1, 40))
    surf_.blit(surf, [p, 0])
    #surf_.convert()
    #surf_.set_colorkey((0, 0, 0))
    return surf_


mob_textures = [get_array_from_surf('ray_casting_textures/mob1.png')]  # change these to pre rendered slices of the mob that can be scaled virticaly
mob_t = []
for t in mob_textures:
    l = []
    for r in range(40):
        l.append(collum2(t, r))
    mob_t.append(l)
mob_textures = mob_t
mobs_map = []
mobs = []
for world_map_ in level_maps:
    l1 = []
    for x in range(len(world_map_)):
        l2 = []
        for y in range(len(world_map_[x])):
            l2.append(False)
        l1.append(l2)
    mobs_map.append(l1)
mobs_map[0][2][2] = True
"""
sky_grade = gradient.color(375)
sky_grade.add(-1 , vec3(25 , 25 , 175))
sky_grade.add(75 , vec3(40 , 40 , 190))
sky_grade.add(150, vec3(60 , 60 , 210))
sky_grade.add(275, vec3(100, 100, 225))
sky_grade.add(326, vec3(125, 125, 255))
sky_grade.add(376, vec3(125, 125, 255))

sky_color = Vec3(125, 125, 255)
sky_colors = []
for y in range(375):
    sky_colors.append(sky_grade.gradeL(y))
ground_color = vec3(0.3 * 255)
ground_colors = []
for y in range(375):
    ground_colors.append(ground_color)#append(mix(sky_color, ground_color, y / 345))
#"""
background = pygame.Surface(vec2(1200, 750))
background.blit(pygame.image.load('ray_casting_background.png'), [0, 0])
"""
for y in range(0, 375):
    for x in range(1200):
        pygame.draw.rect(background, sky_colors[Math.clamp(y + round(Math.smoothstep(abs(x - 600) / 600) * 75), 0, 374)], [x, y  , 1, 1])
    Y = 0
for y in range(375, 750):
    for x in range(1200):
        pygame.draw.rect(background, ground_colors[Math.clamp(Y - abs(round((x - 600) / 10)), 0, 374)], [x, y, 1, 1])
    Y += 1
cols = []
for x in range(1200):
    layer = []
    for y in range(750):
        layer.append(vectorize(background.get_at((x, y))).rgb)
    cols.append(layer)
png.fromArray(cols, 'ray_casting_background.png')
#"""

world_map = level_maps[level]
world_floor_map = level_floor_maps[level]

world_res = 6
n_tile_size = TILESIZE * 25
n_tile_size2 = 8 * 25

speed = 130
player_pos = vec2(TILESIZE * 1.5)
n_player_pos = player_pos / vec2(TILESIZE * 25) * vec2(25 * 8)
player_angle = Math.pi / 4
player_delta = vec2(Math.cos(player_angle) * 5, Math.sin(player_angle) * 5)

scaler_movement = (TILESIZE / 40)

running = True

game_finished = False
speed_run_start = None
while running:
    s = time.time()
    for key in down:
        down[key] = False
        up[key] = False

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            break
        elif event.type == pygame.KEYDOWN:
            if event.key == ord('w'):
                down['w'] = True
                held['w'] = True
            elif event.key == ord('a'):
                down['a'] = True
                held['a'] = True
            elif event.key == ord('s'):
                down['s'] = True
                held['s'] = True
            elif event.key == ord('d'):
                down['d'] = True
                held['d'] = True
            elif event.key == pygame.K_UP:
                down['up'] = True
                held['up'] = True
            elif event.key == pygame.K_LEFT:
                down['left'] = True
                held['left'] = True
            elif event.key == pygame.K_DOWN:
                down['down'] = True
                held['down'] = True
            elif event.key == pygame.K_RIGHT:
                down['right'] = True
                held['right'] = True
            elif event.key == pygame.K_LSHIFT:
                down['shift'] = True
                held['shift'] = True
            elif event.key == ord('e'):
                down['e'] = True
                held['e'] = True
            elif event.key == ord(' '):
                down[' '] = True
                held[' '] = True
            elif event.key == ord('g'):
                down['g'] = True
                held['g'] = True
        elif event.type == pygame.KEYUP:
            if event.key == ord('w'):
                up['w'] = True
                held['w'] = False
            elif event.key == ord('a'):
                up['a'] = True
                held['a'] = False
            elif event.key == ord('s'):
                up['s'] = True
                held['s'] = False
            elif event.key == ord('d'):
                up['d'] = True
                held['d'] = False
            elif event.key == pygame.K_UP:
                up['up'] = True
                held['up'] = False
            elif event.key == pygame.K_LEFT:
                up['left'] = True
                held['left'] = False
            elif event.key == pygame.K_DOWN:
                up['down'] = True
                held['down'] = False
            elif event.key == pygame.K_RIGHT:
                up['right'] = True
                held['right'] = False
            elif event.key == pygame.K_LSHIFT:
                up['shift'] = True
                held['shift'] = False
            elif event.key == ord('e'):
                up['e'] = True
                held['e'] = False
            elif event.key == ord(' '):
                up[' '] = True
                held[' '] = False
            elif event.key == ord('g'):
                up['g'] = True
                held['g'] = False
    
    if not running:
        break
    
    if True in [held['w'], held['a'], held['s'], held['d']] and speed_run_start == None:
        speed_run_start = time.time()

    speed /= scaler_movement
    if held['shift']:
        if True in [held['w'], held['a'], held['s'], held['d']]:
            fov = math.mix(fov, 90, dt * 20)
            speed = math.mix(speed, 195, dt * 10)
        else:
            fov = math.mix(fov, 60, dt * 20)
            speed = math.mix(speed, 130, dt * 10)
    else:
        fov = math.mix(fov, 60, dt * 20)
        speed = math.mix(speed, 130, dt * 10)
    speed *= scaler_movement
    try:
        if held['w']:
            Nplayer_pos = player_pos + Vec2(Math.cos(player_angle) * speed, Math.sin(player_angle) * speed) * Vec2(dt, dt)
            Nplayer_pos2 = player_pos + Vec2(Math.cos(player_angle) * speed * 4, Math.sin(player_angle) * speed * 4) * Vec2(dt, dt)
            if world_map[Math.floor(player_pos.x) >> 6][Math.floor(Nplayer_pos2.y) >> 6] == 0:
                player_pos = Vec2(player_pos.x, Nplayer_pos.y)
            if world_map[Math.floor(Nplayer_pos2.x) >> 6][Math.floor(player_pos.y) >> 6] == 0:
                player_pos = Vec2(Nplayer_pos.x, player_pos.y)
            #if 3 in [world_map[Math.floor(player_pos.x / TILESIZE)][Math.floor(Nplayer_pos2.y / TILESIZE)], world_map[Math.floor(Nplayer_pos2.x / TILESIZE)][Math.floor(player_pos.y / TILESIZE)]]:
            #    level += 1
            #    player_pos = vec2(TILESIZE * 1.5)
        if held['a']:
            Nplayer_pos = player_pos + Vec2(Math.cos(player_angle - Math.pi / 2) * speed, Math.sin(player_angle - Math.pi / 2) * speed) * Vec2(dt, dt)
            Nplayer_pos2 = player_pos + Vec2(Math.cos(player_angle - Math.pi / 2) * speed * 4, Math.sin(player_angle - Math.pi / 2) * speed * 4) * Vec2(dt, dt)
            if world_map[Math.floor(player_pos.x) >> 6][Math.floor(Nplayer_pos2.y) >> 6] == 0:
                player_pos = Vec2(player_pos.x, Nplayer_pos.y)
            if world_map[Math.floor(Nplayer_pos2.x) >> 6][Math.floor(player_pos.y) >> 6] == 0:
                player_pos = Vec2(Nplayer_pos.x, player_pos.y)
            #if 3 in [world_map[Math.floor(player_pos.x / TILESIZE)][Math.floor(Nplayer_pos2.y / TILESIZE)], world_map[Math.floor(Nplayer_pos2.x / TILESIZE)][Math.floor(player_pos.y / TILESIZE)]]:
            #    level += 1
            #    player_pos = vec2(TILESIZE * 1.5)
        if held['s']:
            Nplayer_pos = player_pos + Vec2(-Math.cos(player_angle) * speed, -Math.sin(player_angle) * speed) * Vec2(dt, dt)
            Nplayer_pos2 = player_pos + Vec2(-Math.cos(player_angle) * speed * 4, -Math.sin(player_angle) * speed * 4) * Vec2(dt, dt)
            if world_map[Math.floor(player_pos.x) >> 6][Math.floor(Nplayer_pos2.y) >> 6] == 0:
                player_pos = Vec2(player_pos.x, Nplayer_pos.y)
            if world_map[Math.floor(Nplayer_pos2.x) >> 6][Math.floor(player_pos.y) >> 6] == 0:
                player_pos = Vec2(Nplayer_pos.x, player_pos.y)
            #if 3 in [world_map[Math.floor(player_pos.x / TILESIZE)][Math.floor(Nplayer_pos2.y / TILESIZE)], world_map[Math.floor(Nplayer_pos2.x / TILESIZE)][Math.floor(player_pos.y / TILESIZE)]]:
            #    level += 1
            #    player_pos = vec2(TILESIZE * 1.5)
        if held['d']:
            Nplayer_pos = player_pos + Vec2(Math.cos(player_angle + Math.pi / 2) * speed, Math.sin(player_angle + Math.pi / 2) * speed) * Vec2(dt, dt)
            Nplayer_pos2 = player_pos + Vec2(Math.cos(player_angle + Math.pi / 2) * speed * 4, Math.sin(player_angle + Math.pi / 2) * speed * 4) * Vec2(dt, dt)
            if world_map[Math.floor(player_pos.x) >> 6][Math.floor(Nplayer_pos2.y) >> 6] == 0:
                player_pos = Vec2(player_pos.x, Nplayer_pos.y)
            if world_map[Math.floor(Nplayer_pos2.x) >> 6][Math.floor(player_pos.y) >> 6] == 0:
                player_pos = Vec2(Nplayer_pos.x, player_pos.y)
            #if 3 in [world_map[Math.floor(player_pos.x / TILESIZE)][Math.floor(Nplayer_pos2.y / TILESIZE)], world_map[Math.floor(Nplayer_pos2.x / TILESIZE)][Math.floor(player_pos.y / TILESIZE)]]:
            #    level += 1
            #    player_pos = vec2(TILESIZE * 1.5)
    except IndexError:
        pass
    if held['left']:
        player_angle -= 3 * dt
        if player_angle < 0:
            player_angle += Math.pi * 2
        player_delta = Vec2(Math.cos(player_angle) * 5, Math.sin(player_angle) * 5)
    if held['right']:
        player_angle += 3 * dt
        if player_angle > Math.pi * 2:
            player_angle -= Math.pi * 2
        player_delta = Vec2(Math.cos(player_angle) * 5, Math.sin(player_angle) * 5)
    if down['e']:
        try:
            pos = Vec2(Math.floor(player_pos.x + player_delta.x * 7 * scaler_movement) >> 6, Math.floor(player_pos.y + player_delta.y * 7 * scaler_movement) >> 6)
            if world_map[pos.x][pos.y] in [4, 6]:
                world_map[pos.x][pos.y] = 0
                level_maps[level][pos.x][pos.y] = 0
            elif world_map[pos.x][pos.y] == 3:
                level += 1
                if level == 4:
                    speed_run_end = time.time()
                    game_finished = True
                player_pos = vec2(TILESIZE * 1.5)
                player_angle = Math.pi / 4
                player_delta = vec2(Math.cos(player_angle) * 5, Math.sin(player_angle) * 5)
                world_map = level_maps[level]
                world_floor_map = level_floor_maps[level]
        except IndexError:
            pass
    if down['up']:
        world_res += 1
    if down['down']:
        world_res -= 1
        if world_res <= 0:
            world_res = 1
    if down[' ']:
        if held['shift']:
            if show_map:
                show_map = False
            else:
                show_map = True
        else:
            if render_mode == 'flat':
                render_mode = 'textured'
            else:
                render_mode = 'flat'
    if down['g']:
        grid = []
        for x in range(1200):
            layer = []
            for y in range(750):
                c = screen.get_at((x, y))
                layer.append((c[0], c[1], c[2]))
            grid.append(layer)
        png.fromArray(grid, 'screenshot-ray_casting.png')
    
    screen.blit(background, [0, 0])
    
    rays_data = CastRays()
    depth_buffer = rays_data[1]
    
    """
    mob_pos = Vec2(160, 280)
    angleInRadians = player_angle * (Math.pi / 180)
    cosTheta = Math.cos(angleInRadians)
    sinTheta = Math.sin(angleInRadians)
    X = Math.floor(cosTheta * (mob_pos.x - player_pos.x) - sinTheta * (mob_pos.y - player_pos.y) + player_pos.x)
    Y = Math.floor(sinTheta * (mob_pos.x - player_pos.x) + cosTheta * (mob_pos.y - player_pos.y) + player_pos.y)
    mob_pos = Vec2(X, Y)
    dist_to_mob = mob_pos - player_pos
    dist_to_mob = math.length([dist_to_mob.x, dist_to_mob.y])  # change multiply the dist by the difference in angle of the player to the mob
    depth = dist_to_mob
    height = MAPSIZE * 750 / depth
    heightN = height / 10
    start = 375 - height / 2

    max_right = math.ceil(1200 / world_res)
    for x in range(10):
        mob_x = (mob_pos.x / (depth / 40))
        indexX = round(mob_x / world_res)
        if indexX >= 0 and indexX < max_right and depth_buffer[x + indexX] > depth:
            for y in range(10):
                if mob_textures[0][x][y][3] > 0:
                    pygame.draw.rect(screen, mob_textures[0][x][y], [x * heightN + mob_x, start + y * heightN, heightN, heightN])
    #"""
    
    x_pos_text = 10
    if show_map:
        x_pos_text = 8 * 25 + 10
        pygame.draw.rect(screen, colors[0], [0, 0, 25 * 8, 25 * 8])
        for x in range(25):
            for y in range(25):
                pygame.draw.rect(screen, colors[world_map[x][y]], [x * 8 + 1, y * 8 + 1, 6, 6])
        n_pos = player_pos / vec2(TILESIZE * 25) * vec2(25 * 8)
        n_player_pos = n_pos

        for ray in rays_data[0]:
            pygame.draw.line(screen, (255, 0, 0), n_player_pos, ray, 1)

        pygame.draw.rect(screen, (0, 255, 0), [n_pos[0] - 2, n_pos[1] - 2, 4, 4])
        pygame.draw.line(screen, (0, 255, 0), [n_pos[0] - 1, n_pos[1] - 1], [n_pos[0] - 1 + player_delta.x * 2.5, n_pos[1] - 1 + player_delta.y * 2.5], 2)
    
    UI.text('FPS: ' + str(round(1 / dt, 2)), (255, 255, 0), (x_pos_text, 10), 35)
    UI.text('LEVEL: ' + str(level + 1), (255, 255, 0), (x_pos_text, 30), 35)
    UI.text('RES: ' + str(world_res), (255, 255, 0), (x_pos_text, 55), 35)
    UI.text('Render Mode: ' + ['Flat', 'Textured'][['flat', 'textured'].index(render_mode)], (255, 255, 0), (x_pos_text, 80), 35)
    UI.text('Map: ' + str(show_map), (255, 255, 0), (x_pos_text, 105), 35)
    if game_finished:
        elapsed = speed_run_end - speed_run_start
    else:
        if speed_run_start == None:
            elapsed = 0
        else:
            elapsed = time.time() - speed_run_start
    UI.text('TIME: ' + str(round(elapsed, 4)), (255, 255, 0), (x_pos_text, 130), 35)

    Rscreen.blit(pygame.transform.scale(screen, res), [0, 0])
    pygame.display.update()

    dt = time.time() - s

