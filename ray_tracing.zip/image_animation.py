import pygame, time

pygame.init()

path = 'ray_tracing/Animation' + input('Animtion Number >> ')
image_name = 'ray_trace_out'
type = '.png'

size = int(input('Size >> '))
images = []
for i in range(size):
    images.append(pygame.transform.scale(pygame.image.load(path + '/' + image_name + str(i) + type), (1000, 800)))


screen = pygame.display.set_mode((1000, 800))

frame = 0
dt = 0.000001

paused = False

running = True

while running:
    s = time.time()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            break
        elif event.type == pygame.KEYDOWN:
            if event.key == ord(' '):
                paused = not paused
            elif event.key == pygame.K_RIGHT:
                frame += 1.5
                frame -= dt * 12
                if frame > size - 1:
                    frame = 0
            elif event.key == pygame.K_LEFT:
                frame -= 1.5
                frame -= dt * 12
                if frame < 0:
                    frame = size - 1
    
    if not running:
        break
    
    screen.blit(images[int(frame)], [0, 0])

    pygame.display.update()

    if not paused:
        frame += dt * 12
        if frame > size - 1:
            frame = 0

    e = time.time()
    dt = e - s



