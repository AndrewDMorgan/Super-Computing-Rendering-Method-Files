from Packages.PyVectors import *
import time, random


class Voxel:
    def __init__(self, color: Vec3, surfrace_normal: Vec3, trans: float = 1, reflection: float = 1) -> None:
        self.color = color
        self.surfrace_normal = surfrace_normal
        self.lighting = (-dot(Vec3(sun_derection.x, -sun_derection.y, sun_derection.z), self.surfrace_normal)) / 1.75 + 0.4
        self.color *= Vec3(self.lighting, self.lighting, self.lighting)
        self.trans = trans
        self.reflection = reflection


class Node:
    def __init__(self, start: Vec3, end: Vec3, frames: int, smooth_step_it: bool = False, generate_nodes_at_start: bool = True) -> None:
        self.start = start
        self.end = end
        self.frames = frames
        self.smooth_step_it = smooth_step_it
        
        if generate_nodes_at_start:
            self.Generate()
    def Generate(self) -> None:
        global camera_poses
        for f in range(self.frames):
            k = f / self.frames
            if self.smooth_step_it:
                k = math.smoothstep(k)
            p = mix(self.start, self.end, k)
            camera_poses.append(p)


def Range(k: float, l: float, r: float) -> bool:
    return k >= l and k < r


class Ray:
    def __init__(self, pos: vec3, derection: vec3, depth: int = 0) -> None:
        self.pos = pos
        self.derection = derection
        self.depth = depth
    def Trace(self) -> None:
        depth = self.depth
        coverage = 1.7 / 1000
        derection = self.derection
        p = Vec3(self.pos.x, self.pos.y, self.pos.z)
        P = floor(p)
        if not Range(P.x, 0, map_size.x) or not Range(P.y, 0, map_size.y) or not Range(P.z, 0, map_size.z):
            total_density = 0
        else:
            total_density = global_density_map[P.x][P.y][P.z]
        steps = 1
        bright_steps = 1
        hit_object = False
        for step in range(STEPS):
            p += self.derection
            if not Range(p.x, 0, map_size.x) or not Range(p.y, 0, map_size.y) or not Range(p.z, 0, map_size.z):
                break
            P = floor(p)
            if blocks[P.x][P.y][P.z][0] != False:
                PHIT = Vec3(P.x, P.y, P.z)
                hit_object = True
            d = global_density_map[P.x][P.y][P.z] - coverage
            total_density += d
            if d > 0.1 or hit_object:
                sun_p = Vec3(p.x, p.y, p.z)
                steps2 = 0
                hit_object2 = False
                total_density2 = 0
                if hit_object:
                    for e in range(4):
                        sun_p += inverted_sun_angle
                for step2 in range(STEPS3):
                    sun_p += inverted_sun_angle
                    if not Range(sun_p.x, 0, map_size.x) or not Range(sun_p.y, 0, map_size.y) or not Range(sun_p.z, 0, map_size.z):
                        if total_density2 > 0 or not hit_object:
                            steps2 += (STEPS3 - steps2) / 6
                        break
                    P = floor(sun_p)
                    d = global_density_map[P.x][P.y][P.z] - coverage
                    total_density2 += d
                    steps2 += 1
                    if blocks[P.x][P.y][P.z][0] != False:  # dont break if object is trans and blend the trans color with the object color and dim the light slightly
                        hit_object2 = True  # reflect light off mirrors (and absorb some of the light based on the reflectivity)
                        break
                steps += steps2
                total_density += total_density2
            steps += 1
            if hit_object:
                break
        bright_steps = steps
        if not hit_object:
            color = vec3(100, 100, 175 + (derection.y / 2 + 0.5) * 75)
        else:
            color = blocks[PHIT.x][PHIT.y][PHIT.z][1].color
            thickness = math.divide0((total_density2 + coverage * steps2), steps2) / 2 + 1
            color /= Vec3(thickness, thickness, thickness)
            if hit_object2:
                color /= Vec3(1.75, 1.75, 1.75)
            if blocks[PHIT.x][PHIT.y][PHIT.z][1].trans < 1 and depth < 120:  # 120 is the maximum depth for transparency and reflection
                color = mix(color, blocks[PHIT.x][PHIT.y][PHIT.z][1].color, blocks[PHIT.x][PHIT.y][PHIT.z][1].trans)
                ray = Ray(p.copy() + derection + derection + derection, derection.copy(), depth = depth + 1)
                ray.Trace()
                color = mix(ray.color, color, blocks[PHIT.x][PHIT.y][PHIT.z][1].trans)
            if blocks[PHIT.x][PHIT.y][PHIT.z][1].reflection < 1 and depth < 120:
                color2 = color
                if blocks[PHIT.x][PHIT.y][PHIT.z][1].trans == 1:
                    color2 = blocks[PHIT.x][PHIT.y][PHIT.z][1].color
                color = mix(color, color2, blocks[PHIT.x][PHIT.y][PHIT.z][1].reflection)
                Nderection = blocks[PHIT.x][PHIT.y][PHIT.z][1].surfrace_normal - (-derection - blocks[PHIT.x][PHIT.y][PHIT.z][1].surfrace_normal)  # reflected vector
                ray = Ray(p.copy() + Nderection + Nderection + Nderection, Nderection.copy(), depth = depth + 1)
                ray.Trace()
                color = mix(ray.color, color, blocks[PHIT.x][PHIT.y][PHIT.z][1].reflection)
        td = max(total_density, 0)
        if td == 0 or steps == 0:
            self.color = color
        else:
            total_density /= steps
            self.acumulated_density = total_density
            self.color = clamp(mix(color, vec3(((1 - total_density) * 1.4) * 255), (td / (bright_steps / 2.25))), 0, 255)


map_size = vec4(1, 225, 100, 225)
STEPS = math.floor(length(map_size))
STEPS3 = STEPS

cloud_mask = array(Vec3(map_size.y, map_size.z, map_size.w), 'constant', 0)
for x in range(1, map_size.y):
    for y in range(map_size.z):
        for z in range(map_size.w):
            cloud_mask[x][y][z] = 1#math.smoothstep((map_size.z - 1 - y) / (map_size.z / 11))  # might need a "1 - math.smoothstep((..."

print('cloud mask')

# array(map_size, 'constant', 0)
weather_mask = array(map_size, 'perlin', [[0, 1.4, 30, 'add']])
print('weather mask')
# array(map_size, 'constant', 0)
cloud_noise = math.map4D(lists.add4D(lists.add4D(noise.worly4D(map_size, 3.75, -0.125, 0.125), noise.worly4D(map_size, 30, -1, 1)), lists.add4D(noise.worly4D(map_size, 7.5, -0.25, 0.25), noise.worly4D(map_size, 15, -0.5, 0.5))), 0, 1)
print('cloud noise 1')
cloud_noise = lists.clamp4D(lists.sub4D(array(map_size, 'constant', 1), lists.mult4D(cloud_noise, weather_mask)), 0, 1)
print('cloud noise 2')
for w in range(map_size.x):
    cloud_noise[w] = lists.mult3D(cloud_noise[w], cloud_mask)
print('cloud noise 4')
# array(map_size, 'constant', 0)
global_density_mapT = lists.sub4D(array(map_size, 'constant', 1), cloud_noise)
print('global clouds')

land_noise2 = png.getArray('really_good_land_perlin.png')  # array(Vec2(map_size.y, map_size.w), 'perlin', [[1, 20, 30, 'add']])
land_noise = array(Vec2(map_size.y, map_size.w), 'constant', None)
size_up = 2
for x in range(map_size.y):
    for z in range(map_size.w):
        #y = z
        #left = round(x / size_up)
        #right = left + 1
        #top = round(y / size_up)
        #bottom = top + 1
        #average = math.mix(math.mix(land_noise2[left][top].r, land_noise2[right][top].r, math.fract(x / size_up)), math.mix(land_noise2[left][bottom].r, land_noise2[right][bottom].r, math.fract(x / size_up)), math.fract(y / size_up))
        land_noise[x][z] = land_noise2[x][z].r
land_noise = math.map2D(land_noise, 2, 75)

print('land noise')

#png.fromArray(land_noise, 'ray_tracing/Animation8/esting_smoothing_on_scaler_feild.png')

sun_derection = normalize(vec3(-0.5, 0.7, 1))
inverted_sun_angle = Vec3(-sun_derection.x, -sun_derection.y, -sun_derection.z)

colors = gradient.color(200)
colors.add(-1, vec3(200, 200, 75 ))
colors.add(15, vec3(200, 200, 75 ))
colors.add(20, vec3(90 , 210, 90 ))
colors.add(25, vec3(90 , 210, 90 ))
colors.add(30, vec3(160, 82 , 45 ))
colors.add(35, vec3(175, 175, 175))
colors.add(50, vec3(175, 175, 175))


"""
add water (transparent and blue)
test transparancy     (when casting a ray twords the sun for lighting, pass through glass and take a bit of the light and alter the color. Make it so light rays arnt cast for glass (or dont affect the color) and same with the cloud lighting within transparent objects)
create reflection and based on the reflectivity, blend the solid color with the final color of the reflections (cast extra ray) based on reflectivity. Also add a depth paramater for transparency and reflection to prevent error from over recersion/too many cast rays starting from one ray.
create dynamic water that contains white foam and other such things
render scene with mountains, oceans, and clouds
"""

water_noise = array(Vec2(map_size.y + 1, map_size.w + 1), 'perlin', [[4, 75 / 47 * 13.6, 25, 'add']])

blocks = array(Vec3(map_size.y, map_size.z, map_size.w), 'constant', [False])
colors_array = array(Vec2(map_size.y - 2, map_size.w - 2), 'constant', None)
for x in range(1, map_size.y - 1):
    for z in range(1, map_size.w - 1):
        a = Vec3(x    , land_noise[x    ][z    ] - 1, z    )
        b = Vec3(x    , land_noise[x    ][z + 1] - 1, z + 1)
        c = Vec3(x + 1, land_noise[x + 1][z    ] - 1, z    )
        v1 = Vec3(b.x - a.x, b.y - a.y, b.z - a.z)
        v2 = Vec3(c.x - a.x, c.y - a.y, c.z - a.z)
        normal = cross(v1, v2)
        color = colors.grade(math.map(land_noise[x][z], 2, 75, 0, 47)) + Vec3(random.randint(-10, 10), random.randint(-10, 10), random.randint(-10, 10))
        for y in range(1, math.floor(land_noise[x][z])):
            blocks[x][map_size.z - y][z] = [True, Voxel(color, normal, trans = 1, reflection = 1)]
            colors_array[x - 1][z - 1] = color
        water_height = math.floor(water_noise[x - 1][z - 1] - land_noise[x][z])
        if water_height > 0:
            my = y + 1
            a = Vec3(x    , water_noise[x    ][z    ] - 1, z    )
            b = Vec3(x    , water_noise[x    ][z + 1] - 1, z + 1)
            c = Vec3(x + 1, water_noise[x + 1][z    ] - 1, z    )
            v1 = Vec3(b.x - a.x, b.y - a.y, b.z - a.z)
            v2 = Vec3(c.x - a.x, c.y - a.y, c.z - a.z)
            normal = cross(v1, v2)
            for y in range(water_height):
                blocks[x][map_size.z - my - y][z] = [True, Voxel(vec3(75, 75, 200), normal, trans = 0.15, reflection = 0.75)]

#"""
# walls that are reflective
normal = normalize(Vec3(0, 0, -1))
for x in range(map_size.y):
    for y in range(map_size.z):
        blocks[x][y][map_size.w - 1] = [True, Voxel(vec3(225, 225, 225), normal, trans = 1, reflection = 0.2)]
normal = normalize(Vec3(1, 0, 0))
for z in range(map_size.w):
    for y in range(map_size.z):
        blocks[0][y][z] = [True, Voxel(vec3(225, 225, 225), normal, trans = 1, reflection = 0.2)]
normal = normalize(Vec3(-1, 0, 0))
for z in range(map_size.w):
    for y in range(map_size.z):
        blocks[map_size.y - 1][y][z] = [True, Voxel(vec3(225, 225, 225), normal, trans = 1, reflection = 0.2)]
# bevaled corners (reflection/normal wise)
normal = normalize(Vec3(-1, 0, -1))
for y in range(map_size.z):
    blocks[map_size.y - 1][y][map_size.w - 1] = [True, Voxel(vec3(225, 225, 225), normal, trans = 1, reflection = 0.2)]
normal = normalize(Vec3(1, 0, -1))
for y in range(map_size.z):
    blocks[0][y][map_size.w - 1] = [True, Voxel(vec3(225, 225, 225), normal, trans = 1, reflection = 0.2)]
# ceiling
normal = normalize(Vec3(0, 1, 0))
for x in range(map_size.y):
    for z in range(map_size.w):
        blocks[x][0][z] = [True, Voxel(vec3(225, 225, 225), normal, trans = 1, reflection = 0.2)]
#"""

"""
generate scene with clouds and everything else and in a heigher res (just one frame needed)  (for supercomputing)
"""

print('blocks')

total_map_depth = map_size.x
current_md = 0
total_frames = 40 * 6
k_map = 0

res = vec2(1200, 750)#vec2(150, 150)
half_res = res / vec2(2)

camera_pos = vec3(0)
camera_poses = []
node1 = Node(vec3(0, 20, 0), vec3(map_size.w - 2, 20, 0), 15, smooth_step_it = False)
node1 = Node(vec3(map_size.w - 2, 20, 0), vec3(map_size.w / 2, 20, 0), 15, smooth_step_it = False)
node1 = Node(vec3(map_size.w / 2, 20, 0), vec3(map_size.w / 2, 20, map_size.y - 2), 15, smooth_step_it = False)
i = 0
for node in camera_poses:
    camera_poses[i] = Vec3(node.x, map_size.z - (max(land_noise[math.floor(node.x)][math.floor(node.z)], water_noise[math.floor(node.x)][math.floor(node.z)]) + 10), node.z)
    i += 1
print('nodes\nstarting')

screen = array(res, 'constant', None)

map_size = vec3(map_size.y, map_size.z, map_size.w)
average_elapsed = 0

for i in range(len(camera_poses)):
    global_density_map = lists.mix3D(global_density_mapT[current_md], global_density_mapT[min(current_md + 1, total_map_depth - 1)], k_map)
    camera_pos = camera_poses[i]
    for x in range(res.x):
        layer_start = time.time()
        for y in range(res.y):
            coord = Vec2(x, y)
            uv = (coord - half_res) / Vec2(half_res.y, half_res.y)  # should be better then "coord / half_res - Vec2(1, 1)"
            rd = normalize(Vec3(uv.x, uv.y, 1))
            ray = Ray(camera_pos, rd)
            ray.Trace()
            screen[x][y] = ray.color
        layer_end = time.time()
        elapsed = round(layer_end - layer_start, 2)
        if i == 0:
            average_elapsed = elapsed
        average_elapsed = (elapsed + average_elapsed) / 2
        print('Layer: ' + str(elapsed), '\nFrame: ' + str(i + 1), '\nTime Remaining: ' + str(elapsed * (res.x - (x + 1)) + average_elapsed * res.x * (total_frames - 2 - i)))
    png.fromArray(screen, 'ray_tracing/Animation15/ray_trace_out' + str(i) + '.png')
    l = min(total_map_depth / total_frames * i, total_map_depth - 1)
    k_map = math.fract(l)
    current_md = math.floor(l)

