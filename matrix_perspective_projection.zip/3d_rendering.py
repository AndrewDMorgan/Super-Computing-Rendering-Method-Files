from PyVectors import *
import pygame, time, copy, random
import math as Math

# add loading of .obj files
# add camera rotation

pygame.init()


class mat4x4:  # row, collum
    def __init__(self):
        self.m = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]


def MultiplyMatrixVector(i, m):
    o = Vec3(0, 0, 0)
    o.x = i.x * m.m[0][0] + i.y * m.m[1][0] + i.z * m.m[2][0] + m.m[3][0]
    o.y = i.x * m.m[0][1] + i.y * m.m[1][1] + i.z * m.m[2][1] + m.m[3][1]
    o.z = i.x * m.m[0][2] + i.y * m.m[1][2] + i.z * m.m[2][2] + m.m[3][2]
    w =   i.x * m.m[0][3] + i.y * m.m[1][3] + i.z * m.m[2][3] + m.m[3][3]
    
    if w != 0:
        o.x /= w
        o.y /= w
        o.z /= w
    
    return o


def text_objects(text, font, color):
    textSurface = font.render(text, True, color)
    return textSurface, textSurface.get_rect()


def message_display(text, x, y, color, size, font = 'pixel.ttf', center = False):
    largeText = pygame.font.Font(font, size)
    TextSurf, TextRect = text_objects(text, largeText, color)
    if center:
        TextRect.center = (x, y)
        screen.blit(TextSurf, TextRect)
    else:
        screen.blit(TextSurf, [x, y])


def getDepth1(elem):
    return (elem[0].x.z + elem[0].y.z + elem[0].z.z) / 3


def rotateAroundXZ(point, orgin):
    #float newPosX = circlePos.x + (sin(player_rot) * length(player_pos - circlePos) + (player_pos.x - circlePos.x));
    #float newPosY = circlePos.y + (cos(player_rot) * length(player_pos - circlePos) + (player_pos.y - circlePos.y));
    X = point.x - (math.sin(cam_rot.x) * math.lengthOfList([(orgin - point).x, (orgin - point).z]) + (orgin.x - point.x))
    Z = point.z - (math.cos(cam_rot.x) * math.lengthOfList([(orgin - point).x, (orgin - point).z]) + (orgin.z - point.z))
    return Vec3(X, point.y, Z)


def createCube(pos, color = vec3(255), Size = 1, addGizmos = False, gizmoColor = (255, 0, 0), gizmoSize = 2):
    global polygons, gizmos
    size = Vec3(Size, Size, Size)
    # south
    polygons.append([Vec3(0, 0, 0) * size + pos, Vec3(0, 1, 0) * size + pos, Vec3(1, 1, 0) * size + pos, color])
    polygons.append([Vec3(0, 0, 0) * size + pos, Vec3(1, 1, 0) * size + pos, Vec3(1, 0, 0) * size + pos, color])
    
    # east
    polygons.append([Vec3(1, 0, 0) * size + pos, Vec3(1, 1, 0) * size + pos, Vec3(1, 1, 1) * size + pos, color])
    polygons.append([Vec3(1, 0, 0) * size + pos, Vec3(1, 1, 1) * size + pos, Vec3(1, 0, 1) * size + pos, color])
    
    # north
    polygons.append([Vec3(1, 0, 1) * size + pos, Vec3(1, 1, 1) * size + pos, Vec3(0, 1, 1) * size + pos, color])
    polygons.append([Vec3(1, 0, 1) * size + pos, Vec3(0, 1, 1) * size + pos, Vec3(0, 0, 1) * size + pos, color])
    
    # west
    polygons.append([Vec3(0, 0, 1) * size + pos, Vec3(0, 1, 1) * size + pos, Vec3(0, 1, 0) * size + pos, color])
    polygons.append([Vec3(0, 0, 1) * size + pos, Vec3(0, 1, 0) * size + pos, Vec3(0, 0, 0) * size + pos, color])
    
    # top
    polygons.append([Vec3(0, 1, 0) * size + pos, Vec3(0, 1, 1) * size + pos, Vec3(1, 1, 1) * size + pos, color])
    polygons.append([Vec3(0, 1, 0) * size + pos, Vec3(1, 1, 1) * size + pos, Vec3(1, 1, 0) * size + pos, color])
    
    # bottom
    polygons.append([Vec3(1, 0, 1) * size + pos, Vec3(0, 0, 1) * size + pos, Vec3(0, 0, 0) * size + pos, color])
    polygons.append([Vec3(1, 0, 1) * size + pos, Vec3(0, 0, 0) * size + pos, Vec3(1, 0, 0) * size + pos, color])
    
    if addGizmos:
        gizmos.append([vec3(0, 0, 0) * size + pos, gizmoColor, gizmoSize])
        gizmos.append([vec3(1, 0, 0) * size + pos, gizmoColor, gizmoSize])
        gizmos.append([vec3(0, 1, 0) * size + pos, gizmoColor, gizmoSize])
        gizmos.append([vec3(0, 0, 1) * size + pos, gizmoColor, gizmoSize])
        gizmos.append([vec3(1, 1, 0) * size + pos, gizmoColor, gizmoSize])
        gizmos.append([vec3(0, 1, 1) * size + pos, gizmoColor, gizmoSize])
        gizmos.append([vec3(1, 0, 1) * size + pos, gizmoColor, gizmoSize])
        gizmos.append([vec3(1, 1, 1) * size + pos, gizmoColor, gizmoSize])


def createSphere(pos, r, detail, sphereColor = vec3(200), addGizmos = False, gizmoColor = (255, 0, 0), gizmoSize = 2):  # divide polygons into meshes
    global polygons, gizmos
    
    pi = 3.14159
    pi2 = pi * 2
    halfPi = pi / 2
    scaler1 = pi2 / detail
    scaler2 = pi / detail
    points = []
    for i in range(detail + 2):
        lon = scaler1 * i - pi
        lonSin = math.sin(lon)
        lonCos = math.cos(lon)
        layer = []
        for j in range(detail + 2):
            lat = scaler2 * j - halfPi
            x = r * lonSin * math.cos(lat)
            y = r * lonSin * math.sin(lat)
            z = r * lonCos
            layer.append(vec3(x, y, z) + pos)
            if addGizmos:
                gizmos.append([vec3(x, y, z) + pos, gizmoColor, gizmoSize])
        points.append(layer)
    
    maxOfLength = length(vec2(detail / 2))
    colorScaler = (255 / detail)
    uvScaler = (detail / 2)
    #light_direction = Vec3(random.uniform(-1, 1), random.uniform(-1, 1), random.uniform(-1, 1))
    #print(light_direction)
    for i in range(detail + 1):
        for j in range(detail + 1):
            i2 = uvScaler - abs(i - uvScaler)
            j2 = uvScaler - abs(j - uvScaler)
            
            centerOfSphere = pos - vec3(r)
            normal = centerOfSphere - points[i][j]
            l = length(normal)
            normal /= vec3(l)
            normal = vec3(normal.x, -normal.y, normal.z)  # this normal is slightly off
            
            color = sphereColor
            
            polygons.append([points[i][j + 1], points[i + 1][j + 1], points[i + 1][j], color, normal])
            polygons.append([points[i][j], points[i][j + 1], points[i + 1][j], color, normal])


def createFibSphere(pos, samples, r, gizmoColor = (255, 0, 0), gizmoSize = 2):
    global gizmos
    pi = 3.14159
    phi = pi * (3. - math.sqrt(5.))  # golden angle in radians
    for i in range(samples):
        y = 1 - (i / float(samples - 1)) * 2  # y goes from 1 to -1
        radius = math.sqrt(1 - y * y)  # radius at y
        
        theta = phi * i  # golden angle increment
        
        x = math.cos(theta) * radius
        z = math.sin(theta) * radius
        
        gizmos.append([vec3(x, y, z) * vec3(r) + pos, gizmoColor, gizmoSize])


def create2SidePlain(pos, size, color, addGizmos = False, gizmoColor = (255, 0, 0), gizmoSize = 2):
    global gizmos, polygons
    
    polygons.append([Vec3(0, 0, 0) * vec3(size) + pos, Vec3(0, 0, 1) * vec3(size) + pos, Vec3(1, 0, 1) * vec3(size) + pos, color])
    polygons.append([Vec3(0, 0, 0) * vec3(size) + pos, Vec3(1, 0, 1) * vec3(size) + pos, Vec3(1, 0, 0) * vec3(size) + pos, color])
    polygons.append([Vec3(1, 0, 1) * vec3(size) + pos, Vec3(0, 0, 1) * vec3(size) + pos, Vec3(0, 0, 0) * vec3(size) + pos, color])
    polygons.append([Vec3(1, 0, 1) * vec3(size) + pos, Vec3(0, 0, 0) * vec3(size) + pos, Vec3(1, 0, 0) * vec3(size) + pos, color])
    
    if addGizmos:
        gizmos.append([vec3(0, 0, 0) * vec3(size) + pos, gizmoColor, gizmoSize])
        gizmos.append([vec3(0, 0, 1) * vec3(size) + pos, gizmoColor, gizmoSize])
        gizmos.append([vec3(1, 0, 1) * vec3(size) + pos, gizmoColor, gizmoSize])
        gizmos.append([vec3(1, 0, 0) * vec3(size) + pos, gizmoColor, gizmoSize])


def interceptWithPlane(plane_p, plane_n, lineStart, lineEnd):
    plane_n = normalize(plane_n)
    plane_d = -dot(plane_n, plane_p)
    ad = dot(lineStart, plane_n)
    bd = dot(lineEnd, plane_n)
    t = (-plane_d - ad) / (bd - ad)
    lineStartToEnd = lineEnd - lineStart
    lineToIntersect = lineStartToEnd * Vec3(t, t, t)
    return lineStart + lineToIntersect


def dist(plane_n, plane_p, p):
    n = normalize(p)
    return (plane_n.x * p.x + plane_n.y * p.y + plane_n.z * p.z - dot(plane_n, plane_p))


def clip(plane_p, plane_n, In_tri):  # fix clipping, some triangles arnt being clipped at all causing the error
    in_tri = [Vec3(In_tri[0].x, In_tri[0].y, In_tri[0].z), Vec3(In_tri[1].x, In_tri[1].y, In_tri[1].z), Vec3(In_tri[2].x, In_tri[2].y, In_tri[2].z)]
    tris = None
    out_tri1 = None
    out_tri2 = None
    plane_n = normalize(plane_n)
    
    inside_points = [None, None, None]
    outside_points = [None, None, None]
    nInsidePointCount = 0
    nOutsidePointCount = 0
    
    d0 = dist(plane_n, plane_p, in_tri[0])
    d1 = dist(plane_n, plane_p, in_tri[1])
    d2 = dist(plane_n, plane_p, in_tri[2])
    
    if (d0 >= 0):
        inside_points[nInsidePointCount] = in_tri[0]
        nInsidePointCount += 1
    else:
        outside_points[nOutsidePointCount] = in_tri[0]
        nOutsidePointCount += 1
    if d1 >= 0:
        inside_points[nInsidePointCount] = in_tri[1]
        nInsidePointCount += 1
    else:
        outside_points[nOutsidePointCount] = in_tri[1]
        nOutsidePointCount += 1
    if d2 >= 0:
        inside_points[nInsidePointCount] = in_tri[2]
        nInsidePointCount += 1
    else:
        outside_points[nOutsidePointCount] = in_tri[2]
        nOutsidePointCount += 1
    
    if nInsidePointCount == 0:
        tris = 0
        return [tris, [out_tri1, out_tri2]]
    if nInsidePointCount == 3:
        out_tri1 = in_tri
        tris = 1
        return [tris, [out_tri1, out_tri2]]
    if nInsidePointCount == 1 and nOutsidePointCount == 2:
        out_tri1 = in_tri
        
        out_tri1[0] = inside_points[0]
        out_tri1[1] = interceptWithPlane(plane_p, plane_n, inside_points[0], outside_points[0])
        out_tri1[2] = interceptWithPlane(plane_p, plane_n, inside_points[0], outside_points[1])
        tris = 1
        
        return [tris, [out_tri1, out_tri2]]
    if nInsidePointCount == 2 and nOutsidePointCount == 1:
        out_tri1 = in_tri
        out_tri2 = in_tri
        
        out_tri1[0] = inside_points[0]
        out_tri1[1] = inside_points[1]
        out_tri1[2] = interceptWithPlane(plane_p, plane_n, inside_points[0], outside_points[0])
        
        out_tri2[0] = inside_points[1]
        out_tri2[1] = out_tri1[2]
        out_tri2[2] = interceptWithPlane(plane_p, plane_n, inside_points[1], outside_points[0])
        
        tris = 2
        
        return [tris, [out_tri1, out_tri2]]


# screen

res = vec2(1200, 750)
halfRes = res / vec2(2)
real_screen = pygame.display.set_mode(res.xy)
screen = pygame.Surface((1200, 750))
mouse_pos_scale_factor = res / vec2(1200, 750)

# projection matrix

Near = 0.1
Far = 1000
fov = 90
aspectRatio = 750 / 1200
fovRad = 1/Math.tan(fov * 0.5 / 180 * 3.14159)

matProdj = mat4x4()

matProdj.m[0][0] = aspectRatio * fovRad
matProdj.m[1][1] = fovRad
matProdj.m[2][2] = Far / (Far - Near)
matProdj.m[3][2] = (Far * Near) / (Far - Near)
matProdj.m[2][3] = 1
matProdj.m[3][3] = 0

# colors

background_color = vec3(225, 225, 255)
text_color = vec3(225, 225, 225)
white = vec3(255, 255, 255)
blue = vec3(0, 0, 200)
green = vec3(0, 200, 0)
black = vec3(0, 0, 0)
red = vec3(255, 0, 0)
yellow = vec3(255, 255, 0)

polygons = []
gizmos = []

"""
noise = getSmoothNoise2D(vec2(22, 22), getRandNoise2D(vec2(22, 22)), 5, 2)

block_map = []
for x in range(20):
    layer = []
    for y in range(20):
        layer2 = []
        for z in range(20):
            heightAtPos = noise[x][z] * 15
            if y > heightAtPos:
                layer2.append(0)
            elif y == heightAtPos:
                layer2.append(1)
            else:
                layer2.append(2)
        layer.append(layer2)
    block_map.append(layer)

for x in range(20):  # fix all of this
    for y in range(20):
        for z in range(20):
            #y = 19 - y_
            if block_map[x][y][z] != 0:
                
                # south
                polygons.append([Vec3(0, 0, 0) + pos, Vec3(0, 1, 0) + pos, Vec3(1, 1, 0) + pos])
                polygons.append([Vec3(0, 0, 0) + pos, Vec3(1, 1, 0) + pos, Vec3(1, 0, 0) + pos])
                
                # east
                polygons.append([Vec3(1, 0, 0) + pos, Vec3(1, 1, 0) + pos, Vec3(1, 1, 1) + pos])
                polygons.append([Vec3(1, 0, 0) + pos, Vec3(1, 1, 1) + pos, Vec3(1, 0, 1) + pos])
                
                # north
                polygons.append([Vec3(1, 0, 1) + pos, Vec3(1, 1, 1) + pos, Vec3(0, 1, 1) + pos])
                polygons.append([Vec3(1, 0, 1) + pos, Vec3(0, 1, 1) + pos, Vec3(0, 0, 1) + pos])
                
                # west
                polygons.append([Vec3(0, 0, 1) + pos, Vec3(0, 1, 1) + pos, Vec3(0, 1, 0) + pos])
                polygons.append([Vec3(0, 0, 1) + pos, Vec3(0, 1, 0) + pos, Vec3(0, 0, 0) + pos])
                
                # top
                polygons.append([Vec3(0, 1, 0) + pos, Vec3(0, 1, 1) + pos, Vec3(1, 1, 1) + pos])
                polygons.append([Vec3(0, 1, 0) + pos, Vec3(1, 1, 1) + pos, Vec3(1, 1, 0) + pos])
                
                # bottom
                polygons.append([Vec3(1, 0, 1) + pos, Vec3(0, 0, 1) + pos, Vec3(0, 0, 0) + pos])
                polygons.append([Vec3(1, 0, 1) + pos, Vec3(0, 0, 0) + pos, Vec3(1, 0, 0) + pos])
                
                # check for air on each side and for every side with air create a face
                
                pos = Vec3(x, y, z)
                pos2 = Vec3(x, y, z)
                pos3 = Vec3(x, y, z + 1)
                
                # add color to blocks
                
                try:  # front face
                    if block_map[x][y][z - 1] == 0:
                        polygons.append([Vec3(0, 0, 0) + pos3, Vec3(0, 1, 0) + pos3, Vec3(1, 1, 0) + pos3, vec3(205, 133, 63)])
                        polygons.append([Vec3(0, 0, 0) + pos3, Vec3(1, 1, 0) + pos3, Vec3(1, 0, 0) + pos3, vec3(205, 133, 63)])
                except IndexError:
                    pass
                try:  # back face
                    if block_map[x][y][z + 1] == 0:
                        polygons.append([Vec3(0, 0, 0) + pos, Vec3(0, 1, 0) + pos, Vec3(1, 1, 0) + pos, vec3(205, 133, 63)])
                        polygons.append([Vec3(0, 0, 0) + pos, Vec3(1, 1, 0) + pos, Vec3(1, 0, 0) + pos, vec3(205, 133, 63)])
                except IndexError:
                    pass
                try:  # top face
                    if block_map[x][y + 1][z] == 0:
                        polygons.append([Vec3(1, 0, 1) + pos2, Vec3(0, 0, 1) + pos2, Vec3(0, 0, 0) + pos2, green])
                        polygons.append([Vec3(1, 0, 1) + pos2, Vec3(0, 0, 0) + pos2, Vec3(1, 0, 0) + pos2, green])
                except IndexError:
                    pass
                try:  # left face
                    if block_map[x + 1][y][z] == 0:
                        polygons.append([Vec3(1, 0, 0) + pos, Vec3(1, 1, 0) + pos, Vec3(1, 1, 1) + pos, vec3(205, 133, 63)])
                        polygons.append([Vec3(1, 0, 0) + pos, Vec3(1, 1, 1) + pos, Vec3(1, 0, 1) + pos, vec3(205, 133, 63)])
                except IndexError:
                    pass
                try:  # right face
                    if block_map[x - 1][y][z] == 0:
                        polygons.append([Vec3(0, 0, 1) + pos, Vec3(0, 1, 1) + pos, Vec3(0, 1, 0) + pos, vec3(205, 133, 63)])
                        polygons.append([Vec3(0, 0, 1) + pos, Vec3(0, 1, 0) + pos, Vec3(0, 0, 0) + pos, vec3(205, 133, 63)])
                except IndexError:
                    pass
                
                try:
                    if block_map[][][] == 0:
                        pass
                except IndexError:
                    pass
                
#"""

#createSphere(vec3(3, -2, 3), 1, 30, vec3(255), True)
#createCube(Vec3(-0.5, -5, -5), vec3(255), 4, True)
#createFibSphere(vec3(5, -2, 2), 1000, 1.5)
#create2SidePlain(vec3(-4, 0, -4), 8, vec3(255), True)

#"""
for x in range(random.randint(20, 30)):
    createCube(Vec3(random.randint(-5, 5), random.randint(-5, 5), random.randint(-5, 5)), Vec3(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)), 1, True)
#"""

check = time.time()
cam_pos = vec3(0)
theta = 0
fps = 0
dt = 0

running = True
held = [False, False, False, False, False, False, False]
cam_rot = vec2(0)
DrawGizmos = False
lightScene = True
drawPolygon = True
drawLines = False
rotateObjects = True
fadeDist = 40
numberOfColors = 16#255

while running:
    frame_start = time.time()
    mouse_pos = pygame.mouse.get_pos()
    mouse_pos = Vec2(mouse_pos[0], mouse_pos[1]) / mouse_pos_scale_factor
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            running = False
            break
        elif event.type == pygame.KEYDOWN:
            if event.key == ord('w'):
                held[0] = True
            elif event.key == ord('a'):
                held[1] = True
            elif event.key == ord('s'):
                held[2] = True
            elif event.key == ord('d'):
                held[3] = True
            elif event.key == ord(' '):
                held[4] = True
            elif event.key == pygame.K_LSHIFT:
                #held[5] = True
                pass
            elif event.key == pygame.K_RSHIFT:
                held[6] = True
            elif event.key == pygame.K_TAB:
                if DrawGizmos:
                    DrawGizmos = False
                else:
                    DrawGizmos = True
            elif event.key == pygame.K_LEFT:
                cam_rot += Vec2(0.25, 0)
            elif event.key == pygame.K_RIGHT:
                cam_rot += Vec2(-0.25, 0)
            elif event.key == pygame.K_LCTRL:
                if lightScene:
                    lightScene = False
                else:
                    lightScene = True
            elif event.key == ord('1'):
                if drawPolygon:
                    drawPolygon = False
                else:
                    drawPolygon = True
            elif event.key == ord('2'):
                if drawLines:
                    drawLines = False
                else:
                    drawLines = True
            elif event.key == ord('3'):
                if rotateObjects:
                    rotateObjects = False
                else:
                    rotateObjects = True
            elif event.key == ord('-'):
                numberOfColors -= 5
                numberOfColors = math.clamp(numberOfColors, 1, 255)
                """
                fov -= 5
                aspectRatio = 750 / 1200
                fovRad = 1/Math.tan(fov * 0.5 / 180 * 3.14159)
                
                matProdj = mat4x4()
                
                matProdj.m[0][0] = aspectRatio * fovRad
                matProdj.m[1][1] = fovRad
                matProdj.m[2][2] = Far / (Far - Near)
                matProdj.m[3][2] = (Far * Near) / (Far - Near)
                matProdj.m[2][3] = 1
                matProdj.m[3][3] = 0
                #"""
            elif event.key == ord('='):
                numberOfColors += 5
                numberOfColors = math.clamp(numberOfColors, 1, 255)
                """
                fov += 5
                aspectRatio = 750 / 1200
                fovRad = 1/Math.tan(fov * 0.5 / 180 * 3.14159)

                matProdj = mat4x4()

                matProdj.m[0][0] = aspectRatio * fovRad
                matProdj.m[1][1] = fovRad
                matProdj.m[2][2] = Far / (Far - Near)
                matProdj.m[3][2] = (Far * Near) / (Far - Near)
                matProdj.m[2][3] = 1
                matProdj.m[3][3] = 0
                #"""
        elif event.type == pygame.KEYUP:
            if event.key == ord('w'):
                held[0] = False
            elif event.key == ord('a'):
                held[1] = False
            elif event.key == ord('s'):
                held[2] = False
            elif event.key == ord('d'):
                held[3] = False
            elif event.key == ord(' '):
                held[4] = False
            elif event.key == pygame.K_LSHIFT:
                #held[5] = False
                pass
            elif event.key == pygame.K_RSHIFT:
                held[6] = False
    
    if held[0]:
        cam_pos += Vec3(0, 0, 0.1) * Vec3(dt, dt, dt)
    if held[1]:
        cam_pos += Vec3(-0.1, 0, 0) * Vec3(dt, dt, dt)
    if held[2]:
        cam_pos += Vec3(0, 0, -0.1) * Vec3(dt, dt, dt)
    if held[3]:
        cam_pos += Vec3(0.1, 0, 0) * Vec3(dt, dt, dt)
    if held[4]:
        cam_pos += Vec3(0, -0.1, 0) * Vec3(dt, dt, dt)
    if held[5]:
        cam_pos += Vec3(0, 0.1, 0) * Vec3(dt, dt, dt)
    if held[6]:
        cam_pos += Vec3(0, 0.1, 0) * Vec3(dt, dt, dt)
    
    screen.fill(background_color.rgb)
    
    # rotation matrix
    
    matRotz = mat4x4()
    matRotx = mat4x4()
    
    matRotz.m[0][0] = math.cos(theta)
    matRotz.m[0][1] = math.sin(theta)
    matRotz.m[1][0] = -math.sin(theta)
    matRotz.m[1][1] = math.cos(theta)
    matRotz.m[2][2] = 1
    matRotz.m[3][3] = 1
    
    hTheta = theta * 0.5
    
    matRotx.m[0][0] = 1
    matRotx.m[1][1] = math.cos(hTheta)
    matRotx.m[1][2] = math.sin(hTheta)
    matRotx.m[2][1] = -math.sin(hTheta)
    matRotx.m[2][2] = math.cos(hTheta)
    matRotx.m[3][3] = 1
    
    """
    new_forward = normalize(target_pos - pos)
    new_up = up - a
    new_right = new_up.cross(new_forward)
    
    pointAt = mat4x4()  # im at 24:20 in the 3rd video of code-it-yourself! 3d graphics engine
    pointAt.m[0][0] = new_right.x
    pointAt.m[1][0] = new_up.x
    pointAt.m[2][0] = new_forward.x
    pointAt.m[3][0] = pos.x
    pointAt.m[0][1] = new_right.y
    pointAt.m[1][1] = new_up.y
    pointAt.m[2][1] = new_forward.y
    pointAt.m[3][1] = pos.y
    pointAt.m[0][2] =
    pointAt.m[1][2] =
    pointAt.m[2][2] =
    pointAt.m[3][2] =
    pointAt.m[0][3] =
    pointAt.m[1][3] =
    pointAt.m[2][3] =
    pointAt.m[3][3] =
    """
    
    completed_polygons = []
    for tri in polygons:
            triRotated = tri
            
            triRotatedZ = [0, 0, 0]
            triRotatedZ[0] = MultiplyMatrixVector(triRotated[0], matRotz)
            triRotatedZ[1] = MultiplyMatrixVector(triRotated[1], matRotz)
            triRotatedZ[2] = MultiplyMatrixVector(triRotated[2], matRotz)
            
            triRotatedZX = [0, 0, 0]
            triRotatedZX[0] = MultiplyMatrixVector(triRotatedZ[0], matRotx)
            triRotatedZX[1] = MultiplyMatrixVector(triRotatedZ[1], matRotx)
            triRotatedZX[2] = MultiplyMatrixVector(triRotatedZ[2], matRotx)
            
            pos1 = triRotatedZX[0]
            pos2 = triRotatedZX[1]
            pos3 = triRotatedZX[2]
            
            triTranslated = [Vec3(pos1.x, pos1.y, pos1.z), Vec3(pos2.x, pos2.y, pos2.z), Vec3(pos3.x, pos3.y, pos3.z)]
            triTranslated[0] -= cam_pos
            triTranslated[1] -= cam_pos
            triTranslated[2] -= cam_pos
            
            #triTranslated[0] = rotateAroundXZ(triTranslated[0], Vec3(0, 0, 0))  # point, orgin
            #triTranslated[1] = rotateAroundXZ(triTranslated[1], Vec3(0, 0, 0))
            #triTranslated[2] = rotateAroundXZ(triTranslated[2], Vec3(0, 0, 0))
            
            line1 = triTranslated[1] - triTranslated[0]
            line2 = triTranslated[2] - triTranslated[0]
            if len(tri) == 5:
                normal = tri[4]
            else:
                normal = Vec3(line1.y * line2.z - line1.z * line2.y, line1.z * line2.x - line1.x * line2.z, line1.x * line2.y - line1.y * line2.x)
            l = length(normal)
            normal /= Vec3(l, l, l)
            
            org = Vec3(0, 0, 0)
            if (not lightScene) or (lightScene and normal.x * (triTranslated[0].x - org.x) + normal.y * (triTranslated[0].y - org.y) + normal.z * (triTranslated[0].z - org.z) < 0):
                
                color = tri[3]
                
                if lightScene:
                    light_direction = Vec3(0, 0, -1)#Vec3(0, -0.5, -0.5)
                    l = length(light_direction)
                    light_direction /= Vec3(l, l, l)
                    dp = normal.x * light_direction.x + normal.y * light_direction.y + normal.z * light_direction.z
                    dp = math.clamp(dp, 0.5, 1.5)
                    color *= Vec3(dp, dp, dp)
                
                color = clamp(color, 0, 255)
                
                clippingData = clip(Vec3(0, 0, 0.1), Vec3(0, 0, 1), triTranslated)
                nClippedTriangles = clippingData[0]
                clipped = clippingData[1]
                
                #color = [black, white, green, red][nClippedTriangles]
                #color *= Vec3(dp, dp, dp)
                #color = clamp(color, 0, 255)
                
                for n in range(nClippedTriangles):  # fix the clipping
                    triProjected = [0, 0, 0]
                    triProjected[0] = (MultiplyMatrixVector(clipped[n][0], matProdj) + Vec3(1, 1, 1)) * Vec3(halfRes.x, halfRes.y, 1)
                    triProjected[1] = (MultiplyMatrixVector(clipped[n][1], matProdj) + Vec3(1, 1, 1)) * Vec3(halfRes.x, halfRes.y, 1)
                    triProjected[2] = (MultiplyMatrixVector(clipped[n][2], matProdj) + Vec3(1, 1, 1)) * Vec3(halfRes.x, halfRes.y, 1)
                    
                    triProjected = Vec3(triProjected[0], triProjected[1], triProjected[2])
                    
                    completed_polygons.append([triProjected, color, (triTranslated[0].z + triTranslated[1].z + triTranslated[2].z) / 3])
    
    completed_polygons.sort(key = getDepth1)
    
    for tri in completed_polygons:  # build depth buffer
        color = tri[1]
        point1,point2,point3 = tri[0].xyz
        if drawPolygon:
            numberOfColors2 = 255 / numberOfColors
            color = mix(color, background_color, tri[2] / fadeDist)
            color /= Vec3(numberOfColors2, numberOfColors2, numberOfColors2)
            color = round(color) * Vec3(numberOfColors2, numberOfColors2, numberOfColors2)
            pygame.draw.polygon(screen, color.rgb, [point1.xy, point2.xy, point3.xy])
        if drawLines:
            pygame.draw.line(screen, black.rgb, point1.xy, point2.xy, 1)
            pygame.draw.line(screen, black.rgb, point2.xy, point3.xy, 1)
            pygame.draw.line(screen, black.rgb, point3.xy, point1.xy, 1)
    
    if DrawGizmos:
        for Point in gizmos:  # read depth buffer to see if you should render
            if Point[0].z > cam_pos.z:
                point = [Vec3(Point[0].x, Point[0].y, Point[0].z), Point[1], Point[2]]
                color = point[1]
                size = point[2] * 2
                hsize = size / 2
                point = point[0]
                point = MultiplyMatrixVector(point, matRotz)
                point = MultiplyMatrixVector(point, matRotx)
                point -= cam_pos
                point = (MultiplyMatrixVector(point, matProdj) + Vec3(1, 1, 1)) * Vec3(halfRes.x, halfRes.y, 1)
                pygame.draw.rect(screen, mix(Vec3(color[0], color[1], color[2]), background_color, (Point[0].z - cam_pos.z) / fadeDist).rgb, [point.x - hsize, point.y - hsize, size, size])
    
    message_display('Position: ' + str(round(cam_pos.x, 2)) + ', ' + str(round(cam_pos.y, 2)) + ', ' + str(round(cam_pos.z, 2)), 600, 25, white, 30, 'pixel.ttf', True)
    message_display('FPS: ' + str(round(fps)), 10, 10, white, 30)
    message_display('Draw Gizmos: ' + str(DrawGizmos) + ' (TAB)', 10, 40, white, 30)
    message_display('Lighting: ' + str(lightScene) + ' (CTRL)', 10, 70, white, 30)
    message_display('Polygons: ' + str(drawPolygon) + ' (1)', 10, 100, white, 30)
    message_display('Lines: ' + str(drawLines) + ' (2)', 10, 130, white, 30)
    message_display('Rotation: ' + str(rotateObjects) + ' (3)', 10, 160, white, 30)
    message_display('Colors: ' + str(numberOfColors) + ' (- | +)', 10, 190, white, 30)
    #message_display('Fov: ' + str(fov) + ' (- | +)', 10, 190, white, 30)
    
    real_screen.blit(pygame.transform.scale(screen, res.xy), [0, 0])
    pygame.display.update()
    
    if rotateObjects:
        theta += 0.025 * dt
    
    dt = (time.time() - frame_start) * 20
    if time.time() - check > 0.25:
        fps = 1 / (dt / 20)
        check = time.time()

