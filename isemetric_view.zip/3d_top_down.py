from PyVectors import *
from world_gen import create_world
import pygame, time, random

pygame.init()


"""  # the plans
game:
    make it have loads of gameplay
    add water physics and sand pysics
    bioms, different terrain generation for each biom, and struchers that are biom dependent and have puzzles for the player to solve
    trees
    add a zoom featur??


modding:
    make modding easy as posible
    make it easier to cusomize terrain generation without out having to alter the mian terrain generation script
"""


def move_water(pos):
    try:
        if map[pos.x + 1][pos.y][pos.z] == 0:
            map[pos.x + 1][pos.y][pos.z] = 14
    except IndexError:
        pass
    try:
        if map[pos.x - 1][pos.y][pos.z] == 0:
            map[pos.x - 1][pos.y][pos.z] = 17
    except IndexError:
        pass
    try:
        if map[pos.x - 1][pos.y][pos.z + 1] == 0:
            map[pos.x - 1][pos.y][pos.z + 1] = 12
    except IndexError:
        pass
    try:
        if map[pos.x + 1][pos.y][pos.z - 1] == 0:
            map[pos.x + 1][pos.y][pos.z - 1] = 15
    except IndexError:
        pass
    try:
        if map[pos.x][pos.y - 1][pos.z] == 0:
            map[pos.x][pos.y - 1][pos.z] = 6
    except IndexError:
        pass


def color_at(image, x, y):
    colorkey = image.get_at((x, y))
    colorkey = (colorkey[0], colorkey[1], colorkey[2])
    return colorkey


def get_block_side(point_on_block):
    try:
        new_pos = point_on_block
        color = color_at(image_for_block_side, new_pos.x, new_pos.y)
        if color == (255, 255, 255):
            return 0
        elif color[2] > 100:
            return 2
        elif color[0] > 100:
            return 1
        else:
            return -1
    except IndexError:
        return -1


def text_objects(text, font, color):
    textSurface = font.render(text, True, color)
    return textSurface, textSurface.get_rect()


def message_display(text, x, y, color, size, font = 'pixel.ttf', center = False, trans = 255):
    largeText = pygame.font.Font(font, size)
    TextSurf, TextRect = text_objects(text, largeText, color)
    TextSurf.set_alpha(trans)
    if center:
        TextRect.center = (x, y)
        screen.blit(TextSurf, TextRect)
    else:
        screen.blit(TextSurf, [x, y])


def load_resorce_pack(file):  # move this to the top when down
    global player_pos, mouse_image, collide_tile_top, water_tiles, tiles, map_size
    info = open(file).read().split('\n')

    map_size_data = info[1].split(',')
    map_size = vec3(int(map_size_data[0]), int(map_size_data[1]), int(map_size_data[2]))

    tiles = []
    for image in info[3].split(','):
        tiles.append(pygame.image.load(image))

    water_tiles = []
    for num in info[5].split(','):
        water_tiles.append(int(num))

    collide_tile_top = pygame.image.load(info[7])
    mouse_image = pygame.image.load(info[9])

    player_pos_data = info[11].split(',')
    player_pos = vec3(int(player_pos_data[0]), int(player_pos_data[1]), int(player_pos_data[2]))


map_size = None
tiles = None
water_tiles = None
collide_tile_top = None
mouse_image = None
player_pos = None

load_resorce_pack('resorce-Game.txt')

res = vec2(1200, 750)#vec2(1440, 900)
screen = pygame.Surface((1200, 750))
res_scaling = res / vec2(1200, 750)
scaled_screen = pygame.display.set_mode(res.xy)

seed = None

influnece_map = []
map = []
total_move = 0

held = [False, False, False, False, False]
chunks = {}

pygame.mouse.set_visible(False)

rect = pygame.Rect([0, 0, 29, 41])
image_for_block_side = pygame.Surface(rect.size).convert()
image_for_block_side.blit(collide_tile_top, (0, 0), rect)

mouse_img = pygame.Surface((4, 4))
mouse_img.fill((0, 0, 0))
mouse_img.set_alpha(0)

dt = 0
fps = 0

player_or_break = 'place'
block_in_hand = 3

seed, map, influnece_map = create_world(0, map_size)

chunks['0,0'] = map
last_mouse_pos = vec2(0)
mouse_set = vec2(0)


running = True


while running:
    start_frame = time.time()
    pressed = [False, False]
    total_move = 0
    mouse_pos = pygame.mouse.get_pos()
    mouse_pos = vec2(mouse_pos[0], mouse_pos[1]) / res_scaling
    mouse_pos = vec2(int(mouse_pos.x), int(mouse_pos.y))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                player_pos.z += 1
                total_move += 10
            if event.key == pygame.K_LEFT:
                player_pos.x -= 1
                total_move -= 5
            if event.key == pygame.K_DOWN:
                player_pos.z -= 1
                total_move -= 10
            if event.key == pygame.K_RIGHT:
                player_pos.x += 1
                total_move += 5
            elif event.key == ord('w'):
                held[0] = True
            elif event.key == ord('a'):
                held[1] = True
            elif event.key == ord('s'):
                held[2] = True
            elif event.key == ord('d'):
                held[3] = True
            elif event.key == ord(' '):
                if player_or_break == 'place':
                    player_or_break = 'break'
                else:
                    player_or_break = 'place'
        elif event.type == pygame.KEYUP:
            if event.key == ord('w'):
                held[0] = False
            elif event.key == ord('a'):
                held[1] = False
            elif event.key == ord('s'):
                held[2] = False
            elif event.key == ord('d'):
                held[3] = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 3:
                mouse_set = mouse_pos
                held[4] = True
                pressed[0] = True
            elif event.button == 1:
                pressed[1] = True
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 3:
                held[4] = False
    
    if held[4] and not pressed[0]:
        last_mouse_pos = last_mouse_pos + (mouse_pos - mouse_set)
        mouse_set = mouse_pos
    
    
    screen.fill((225, 225, 255))
    
    player_chunk_pos = player_pos
    try:  # make it so the chunks dictionary stores the seed instead of data. Load the seeded map when you change island snipit     this also may improve preformance and will reduce memory consumption for saves and the current loaded world
        map = chunks[str(player_chunk_pos.x) + ',' + str(player_chunk_pos.z)]
    except KeyError:
        seed, map, influnece_map = create_world(total_move, map_size)
        chunks[str(player_chunk_pos.x) + ',' + str(player_chunk_pos.z)] = map
    
    blocks = []
    block_poses = []
    for y in range(map_size.y):  # try not to have this generate every frame
        for z in range(map_size.z):
            for x in range(map_size.x):
                if map[x][y][z] != 0:
                    air = False
                    try:
                        data = [map[x + 1][y][z], map[x - 1][y][z + 1], map[x][y + 1][z], map[x - 1][y][z]]
                        if 0 in data or 4 in data or 0 in [x, z]:
                            air = True
                    except IndexError:
                        air = True
                    
                    if air:
                        X = (x * 14)
                        Y = (z * 29) - (y * 12) + (x * 14)
                        block = screen.blit(tiles[map[x][y][z]], [X + last_mouse_pos.x, Y + last_mouse_pos.y])
                        #if map[x][y][z] == 4:
                        #    move_water(vec3(x, y, z))
                        if pressed[1]:
                            if (player_or_break == 'place' and map[x][y][z] != 4) or player_or_break == 'break':
                                if block.collidepoint(mouse_pos.xy):
                                    blocks.append(block)
                                    block_poses.append([x, y, z])
    
    
    message_display('X: ' + str(player_pos.x) + '    Y: ' + str(player_pos.z), 10, 10, (255, 255, 255), 25)
    message_display('FPS: ' + str(fps), 10, 30, (255, 255, 255), 25)
    
    
    scaled_screen.fill((225, 225, 255))
    scaled_screen.blit(pygame.transform.scale(screen, res.xy), [0, 0])
    
    real_pos = pygame.mouse.get_pos()
    scaled_screen.blit(mouse_image, [real_pos[0] - 4, real_pos[1] - 4])
    
    pygame.display.update()
    
    
    if pressed[1] and len(block_poses) > 0:
        try:
            new_poses = []
            repeat = 0
            for hit in blocks:
                pos = block_poses[repeat]
                x,y,z = pos
                X = (x * 14) + last_mouse_pos.x
                Y = (z * 29) - (y * 12) + (x * 14) + last_mouse_pos.y
                point_on_block = vec2(mouse_pos.x - X, mouse_pos.y - Y)
                if get_block_side(point_on_block) != -1:
                    new_poses.append(pos)
                repeat += 1
            
            block_poses = new_poses
            
            zs = []
            for hit in block_poses:
                zs.append(hit[2])
            
            z = max(zs)
            
            all = []
            for hit in block_poses:
                if hit[2] == z:
                    all.append(hit)
            
            xs = []
            for hit in all:
                xs.append(hit[0])
            
            x = max(xs)
            
            final_ = []
            for hit in all:
                if hit[0] == x:
                    final_.append(hit)
            
            ys = []
            for hit in final_:
                ys.append(hit[1])
            
            y = max(ys)
            
            final = []
            for hit in final_:
                if hit[1] == y:
                    final = hit
            
            if player_or_break == 'break':
                try:
                    map[final[0]][final[1]][final[2]] = 0
                except IndexError:
                    pass
            elif player_or_break == 'place':
                x,y,z = final
                X = (x * 14) + last_mouse_pos.x
                Y = (z * 29) - (y * 12) + (x * 14) + last_mouse_pos.y
                try:
                    point_on_block = vec2(mouse_pos.x - X, mouse_pos.y - Y)
                    block_side = get_block_side(point_on_block)
                    if block_side == 0:
                        if map[x][y + 1][z] in [0, 4]:
                            map[x][y + 1][z] = block_in_hand
                    if block_side == 1:
                        if map[x - 1][y][z + 1] in [0, 4]:
                            map[x - 1][y][z + 1] = block_in_hand
                    if block_side == 2:
                        if map[x + 1][y][z] in [0, 4]:
                            map[x + 1][y][z] = block_in_hand
                except IndexError:
                    pass
        except ValueError:
            pass
    
    dt = (time.time() - start_frame) * 20
    fps = round(1 / (time.time() - start_frame))


pygame.quit()
