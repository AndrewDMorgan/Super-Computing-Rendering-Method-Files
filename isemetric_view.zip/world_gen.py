from OctiveNoise import *
from PyVectors import *
import random


def create_world(total_move, map_size, randSeed = True):
    if randSeed == True:
        seed_ = random.randint(0, 100000) + (total_move * 5)
    else:
        seed_ = randSeed
    
    print(seed_)
    
    random.seed(seed_)
    
    influnece_map = []
    
    caveNoise = []
    caveRNoise = []
    for x in range(map_size.x):
        layerX = []
        for y in range(map_size.y):
            layerY = []
            for z in range(map_size.z):
                layerY.append(random.uniform(-1.00, 1.00))
            layerX.append(layerY)
        caveRNoise.append(layerX)
    
    for x in range(map_size.x):
        layerX = []
        for y in range(map_size.y):
            layerY = []
            for z in range(map_size.z):
                layerY.append(noise.ridge3D(caveRNoise, 10, x, y, z))
            layerX.append(layerY)
        caveNoise.append(layerX)
    
    caveNoise = math.map3D(caveNoise, -1, 1, 0, 1)
    
    #heights = getSmoothNoise2D(map_size, getRandNoise2D(map_size, seed_), 3, 2)
    
    landNoise = []
    landRNoise = []
    for x in range(map_size.x):
        layerX = []
        for y in range(map_size.y):
            layerX.append(random.uniform(0.00, 1.00))
        landRNoise.append(layerX)
    
    for x in range(map_size.x):
        layerX = []
        for y in range(map_size.y):
            layerX.append(noise.perlin2D(landRNoise, 10, x, y))
        landNoise.append(layerX)
    
    heights = landNoise
    
    x_ = 0
    for x in heights:
        layer = []
        for y in x:
            layer.append(int(y * 15))
        heights[x_] = layer
        x_ += 1
    
    water_height = 12
    
    map = []
    tree_poses = []
    for x in range(map_size.x):
        layerY = []
        for y in range(map_size.y):
            layerZ = []
            for z in range(map_size.z):
                height_at_pos = heights[x][z] + 9
                caveTresh = 0.85
                if caveNoise[x][y][z] > caveTresh:
                    height_at_pos = -20
                if y > height_at_pos:
                    if y <= water_height and caveNoise[x][y][z] <= caveTresh:
                        block = 4
                    else:
                        block = 0
                else:
                    if y == height_at_pos:
                        if y <= water_height:
                            block = 5
                        else:
                            block = 1
                            if random.randint(0, 25) == 1:
                                if len(tree_poses) > 0:
                                    all_dists = []
                                    for tree in tree_poses:
                                        all_dists.append(dists.distToPoint(vec3(x, y, z), vec3(tree[0], tree[1], tree[2])))
                                    if min(all_dists) > 5:
                                        tree_poses.append([x, y + 1, z])
                                else:
                                    tree_poses.append([x, y + 1, z])
                    else:
                        if y in range(height_at_pos - 3, height_at_pos):
                            block = 2
                        else:
                            block = 3
                layerZ.append(block)
            layerY.append(layerZ)
        map.append(layerY)
    
    for tree in tree_poses:
        tree_height = random.randint(4, 7)
        for y in range(tree_height - 1):
            try:
                map[tree[0]][tree[1] + y][tree[2]] = 18
            except IndexError:
                pass
        try:
            map[tree[0] - 1][tree[1] + tree_height - 3][tree[2]] = 19
        except IndexError:
            pass
        try:
            map[tree[0] + 1][tree[1] + tree_height - 3][tree[2]] = 19
        except IndexError:
            pass
        try:
            map[tree[0]][tree[1] + tree_height - 3][tree[2] + 1] = 19
        except IndexError:
            pass
        try:
            map[tree[0]][tree[1] + tree_height - 3][tree[2] - 1] = 19
        except IndexError:
            pass
        try:
            map[tree[0] - 1][tree[1] + tree_height - 3][tree[2] + 1] = 19
        except IndexError:
            pass
        try:
            map[tree[0] + 1][tree[1] + tree_height - 3][tree[2] - 1] = 19
        except IndexError:
            pass
        try:
            map[tree[0] - 2][tree[1] + tree_height - 3][tree[2] + 1] = 19
        except IndexError:
            pass
        try:
            map[tree[0] + 2][tree[1] + tree_height - 3][tree[2] - 1] = 19
        except IndexError:
            pass
        
        try:
            map[tree[0] - 1][tree[1] + tree_height - 2][tree[2]] = 19
        except IndexError:
            pass
        try:
            map[tree[0] + 1][tree[1] + tree_height - 2][tree[2]] = 19
        except IndexError:
            pass
        try:
            map[tree[0] - 1][tree[1] + tree_height - 2][tree[2] + 1] = 19
        except IndexError:
            pass
        try:
            map[tree[0] + 1][tree[1] + tree_height - 2][tree[2] - 1] = 19
        except IndexError:
            pass
        
        try:
            map[tree[0] - 1][tree[1] + tree_height - 1][tree[2]] = 19
        except IndexError:
            pass
        try:
            map[tree[0] + 1][tree[1] + tree_height - 1][tree[2]] = 19
        except IndexError:
            pass
        try:
            map[tree[0] - 1][tree[1] + tree_height - 1][tree[2] + 1] = 19
        except IndexError:
            pass
        try:
            map[tree[0] + 1][tree[1] + tree_height - 1][tree[2] - 1] = 19
        except IndexError:
            pass
        try:
            map[tree[0]][tree[1] + tree_height - 1][tree[2]] = 19
        except IndexError:
            pass
    return [seed_, map, influnece_map]
